package P3;

import java.util.ArrayList;
import java.util.List;

class Person {
    private static final List<String> nameList = new ArrayList<>();

    private final String name;

    Person(String name) {
        if (!nameList.contains(name)) {
            this.name = name;
            nameList.add(name);
        }
        else
        {
            this.name="";
            System.exit(0);
        }
    }

    String getName() {
        return name;
    }
}
