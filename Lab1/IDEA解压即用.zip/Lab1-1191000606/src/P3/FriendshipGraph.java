package P3;

import java.util.ArrayList;
import java.util.List;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedDeque;

public class FriendshipGraph {
    private final List<Person> Vertex = new ArrayList<>();
    private final List<List<Boolean>> Edges = new ArrayList<>();

    private final Boolean False = Boolean.FALSE;
    private final Boolean True = Boolean.TRUE;

    /**
     * Defensive copy.
     *
     * @return a copy of Vertex. When the copy is changed, Vertex won't change.
     */
    public List<Person> getVertex() {
        return new ArrayList<>(Vertex);
    }

    /**
     * Defensive copy
     *
     * @return a copy of Edges. When the copy is changed, Edges won't change.
     */
    public List<List<Boolean>> getEdges() {
        List<List<Boolean>> retEdges = new ArrayList<>();

        for (List<Boolean> edge : Edges) {
            retEdges.add(new ArrayList<>(edge));
        }

        return retEdges;
    }

    /**
     * add an vertex to Vertex and update Edges. There is no edge between one vertex so set False
     *
     * @param p an given Person object without any friendship, seen as an new vertex in Graph
     */
    public void addVertex(Person p) {
        Vertex.add(p);

        for (List<Boolean> edge : Edges) {
            edge.add(False);
        }

        List<Boolean> newEdge = new ArrayList<>();

        for (int i = 0; i < Vertex.size(); i++) {
            newEdge.add(False);
        }

        Edges.add(newEdge);
    }

    /**
     * add an edge between two vertex
     *
     * @param p Edge start vertex
     * @param q Edge end vertex
     */
    public void addEdge(Person p, Person q) {
        int pIndex = Vertex.indexOf(p);
        int qIndex = Vertex.indexOf(q);
        Edges.get(pIndex).set(qIndex, True);
        Edges.get(qIndex).set(pIndex, True);
    }

    /**
     * get the length of way from p to q. Define the num of edges of the way as its length
     *
     * @param p start vertex
     * @param q end vertex
     * @return If there exists many ways, return the min length. If there is no way, return -1
     */
    public int getDistance(Person p, Person q) {
        int[] distances = new int[Vertex.size()];

        for (int i = 0; i < Vertex.size(); i++) {
            distances[i] = -1;
        }

        distances[Vertex.indexOf(p)] = 0;

        Queue<Person> queue = new ConcurrentLinkedDeque<>();

        queue.add(p);

        while (true) {
            Person head = queue.peek();

            if (head == q || head == null) {
                break;
            }

            int index = Vertex.indexOf(head);

            List<Boolean> edge = Edges.get(index);

            for (int i = 0; i < edge.size(); i++) {
                if (edge.get(i) && distances[i] == -1) {
                    queue.add(Vertex.get(i));
                    distances[i] = distances[index] + 1;
                }
            }

            queue.poll();
        }

        return distances[Vertex.indexOf(q)];
    }

    /**
     * client code
     *
     * @param args unused
     */
    public static void main(String[] args) {
        FriendshipGraph graph = new FriendshipGraph();
        Person rachel = new Person("Rachel");
        Person ross = new Person("Ross");
        Person ben = new Person("Ben");
        Person kramer = new Person("Kramer");
        graph.addVertex(rachel);
        graph.addVertex(ross);
        graph.addVertex(ben);
        graph.addVertex(kramer);
        graph.addEdge(rachel, ross);
        graph.addEdge(ross, rachel);
        graph.addEdge(ross, ben);
        graph.addEdge(ben, ross);
        System.out.println(graph.getDistance(rachel, ross));
        System.out.println(graph.getDistance(rachel, ben));
        System.out.println(graph.getDistance(rachel, rachel));
        System.out.println(graph.getDistance(rachel, kramer));
    }
}
