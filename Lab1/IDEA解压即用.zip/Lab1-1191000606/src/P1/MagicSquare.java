package P1;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.io.*;

public class MagicSquare {
    public static void main(String[] args) {
        System.out.println("*************************************************");
        System.out.println("**有两种模式：T,P,分别表示判断是否幻方和生成幻方");
        System.out.println("**如为判断幻方（T），请带上文件名作为参数，以空格分隔");
        System.out.println("**如为生成幻方（P），请带上n作为参数，以空格分隔");
        System.out.println("*************************************************");

        Scanner scan;

        while (true) {
            System.out.println("请输入模式(或输入over以结束)");

            scan = new Scanner(System.in);
            String str = scan.nextLine();

            if (str.equals("over")) {
                scan.close();
                return;
            } else if (str.charAt(0) == 'T') {
                System.out.println(isLegalMagicSquare(str.substring(2)));
            } else if (str.charAt(0) == 'P') {
                int n;

                try {
                    n = Integer.parseInt(str.substring(2));
                } catch (NumberFormatException e1) {
                    System.out.println("n需要为整数");
                    continue;
                }

                if (generateMagicSquare(n)) {
                    System.out.println("Success to generate MagicSquare in 6.txt");
                }
            }
        }
    }

    public static boolean isLegalMagicSquare(String filename) {
        File file = new File("." + File.separator + "src" + File.separator + "P1" + File.separator + "txt" + File.separator + filename);
        BufferedReader reader;

        try {
            reader = new BufferedReader(new FileReader(file));
        } catch (FileNotFoundException e2) {
            System.err.println("File is not found");
            return false;
        }

        List<String> lines_str = new ArrayList<>();

        while (true) {
            String line = null;

            try {
                line = reader.readLine();
            } catch (IOException e3) {
                System.err.println("Fail to read the file");
            }

            if (line != null) {
                lines_str.add(line);
            } else {
                break;
            }
        }

        try {
            reader.close();
        } catch (IOException e4) {
            e4.printStackTrace();
        }

        int line_num = lines_str.size();
        int[][] lines_int = new int[line_num][line_num];
        String[] line_str;

        for (int i = 0; i < line_num; i++) {
            line_str = lines_str.get(i).split("\t");

            int j = 0;

            for (String word : line_str) {
                try {
                    lines_int[i][j++] = Integer.parseInt(word);
                    if (Integer.parseInt(word) <= 0) {
                        System.out.println("第" + (i + 1) + "行" + "第" + j + "个数为负整数或0");
                        return false;
                    }
                } catch (NumberFormatException e5) {
                    try {
                        Double.parseDouble(word);
                        System.out.println("第" + (i + 1) + "行" + "第" + j + "个数为小数");
                    } catch (NumberFormatException e6) {
                        System.out.println("第" + (i + 1) + "行" + "第" + j + "个数出现非/t分隔符");
                    }
                    return false;
                }
            }

            if (j != line_num) {
                System.out.println("第" + (i + 1) + "行只有" + j + "个数,应有" + line_num + "个数");
                return false;
            }
        }

        int total_standard = 0;
        int total_diagonal_0 = 0;
        int total_diagonal_1 = 0;

        for (int i = 0; i < line_num; i++) {
            total_standard += lines_int[0][i];
            total_diagonal_0 += lines_int[i][i];
            total_diagonal_1 += lines_int[i][line_num - 1];
        }

        if (total_diagonal_0 != total_standard || total_diagonal_1 != total_standard) {
            System.out.println("对角线之和与第一行和不同");
            return false;
        }

        for (int i = 0; i < line_num; i++) {
            int total_line = 0;
            int total_row = 0;

            for (int j = 0; j < line_num; j++) {
                total_line += lines_int[i][j];
                total_row += lines_int[j][i];
            }

            if (total_line != total_standard) {
                System.out.println("第" + (i + 1) + "行与第一行和不同");
                return false;
            }

            if (total_row != total_standard) {
                System.out.println("第" + (i + 1) + "列与第一行和不同");
                return false;
            }
        }

        return true;
    }

    public static boolean generateMagicSquare(int n) {
        if (n < 0) {
            System.out.println("n不能为负数");
            return false;
        }

        if (n % 2 == 0) {
            System.out.println("n不能为偶数");
            return false;
        }

        File file = new File("." + File.separator + "src" + File.separator + "P1" + File.separator + "txt" + File.separator + "6.txt");

        BufferedWriter writer;

        try {
            writer = new BufferedWriter(new FileWriter(file));
        } catch (IOException e7) {
            System.err.println("Fail to write the file");
            return false;
        }

        int[][] magic = new int[n][n];
        int row = 0, col = n / 2, i, j, square = n * n;

        for (i = 1; i <= square; i++) {
            magic[row][col] = i;
            if (i % n == 0)
                row++;
            else {
                if (row == 0)
                    row = n - 1;
                else
                    row--;
                if (col == (n - 1))
                    col = 0;
                else
                    col++;
            }
        }

        try {
            for (i = 0; i < n; i++) {
                for (j = 0; j < n; j++)
                    writer.write(magic[i][j] + "\t");
                writer.write("\n");
            }

            writer.flush();
            writer.close();
        } catch (IOException e8) {
            System.err.println("Fail to save the file");
        }

        return true;
    }
}
