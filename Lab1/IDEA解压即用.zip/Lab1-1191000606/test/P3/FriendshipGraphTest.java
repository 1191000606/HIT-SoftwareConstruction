package P3;

import org.junit.Assert;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

public class FriendshipGraphTest {
    private final Boolean True = Boolean.TRUE;
    private final Boolean False = Boolean.FALSE;

    /**
     * Testing strategy
     *
     * Test some special kinds of input String.
     * Covers:  empty,  mixed of num and char,  Chinese characters
     */
    @Test
    public void addVertexTest() {
        FriendshipGraph graph = new FriendshipGraph();
        List<Person> personList = new ArrayList<>();

        Person emptyName = new Person("");
        personList.add(emptyName);
        graph.addVertex(emptyName);
        Assert.assertEquals(personList, graph.getVertex());

        Person mixedName = new Person("1191000606cyf");
        personList.add(mixedName);
        graph.addVertex(mixedName);
        Assert.assertEquals(personList, graph.getVertex());

        Person chineseName = new Person("陈一帆");
        personList.add(chineseName);
        graph.addVertex(chineseName);
        Assert.assertEquals(personList, graph.getVertex());
    }

    /**
     * Test if success add edge
     */
    @Test
    public void addEdgeTest() {
        FriendshipGraph graph = new FriendshipGraph();
        List<List<Boolean>> edges = new ArrayList<>();

        Person p = new Person("CYF");
        Person q = new Person("cyf");
        List<Boolean> edge0 = new ArrayList<>();
        List<Boolean> edge1 = new ArrayList<>();

        graph.addVertex(p);
        graph.addVertex(q);
        graph.addEdge(p, q);

        edges.add(edge0);
        edges.add(edge1);
        edge0.add(False);
        edge0.add(True);
        edge1.add(True);
        edge1.add(False);

        Assert.assertEquals(edges, graph.getEdges());
    }

    /**
     * test whether the Vertex in Graph will change when the return Vertex are changed. And in turn.
     *
     * Testing strategy
     *
     * Partition the changes as follows:
     * changes type:    add new vertex to Vertex,   reset inner vertex in Vertex
     * changes source:  Vertex in Graph,            return Vertex
     */
    @Test
    public void getVertexTest() {
        FriendshipGraph graph = new FriendshipGraph();
        graph.addVertex(new Person("A"));
        graph.addVertex(new Person("B"));

        List<Person> retVertex0 = graph.getVertex();
        List<Person> retVertex1 = graph.getVertex();
        List<Person> retVertex2 = graph.getVertex();

        retVertex1.add(new Person("C"));
        retVertex2.set(0, new Person("D"));
        Assert.assertNotEquals(retVertex0, retVertex1);
        Assert.assertNotEquals(retVertex0, retVertex2);

        // Note: we don't have a method to reset the inner vertex of Vertex in Graph.
        graph.addVertex(new Person("E"));
        Assert.assertNotEquals(retVertex0, graph.getVertex());
    }

    /**
     * test whether the Edges in Graph will change when the return Edges are changed. And in turn.
     *
     * Testing strategy
     *
     * Partition the changes as follows:
     * changes type:    add new edges to Edges,   reset inner edges in Edges
     * changes source:  Edges in Graph,           return Edges
     */
    @Test
    public void getEdgesTest() {
        FriendshipGraph graph = new FriendshipGraph();
        Person p0 = new Person("0");
        Person p1 = new Person("1");
        Person p2 = new Person("2");
        Person p3 = new Person("3");
        Person p4 = new Person("4");
        graph.addVertex(p0);
        graph.addVertex(p1);
        graph.addVertex(p2);
        graph.addVertex(p3);
        graph.addVertex(p4);

        graph.addEdge(p0, p1);
        graph.addEdge(p1, p4);

        List<List<Boolean>> retEdges0 = graph.getEdges();
        List<List<Boolean>> retEdges1 = graph.getEdges();
        List<List<Boolean>> retEdges2 = graph.getEdges();

        retEdges1.add(new ArrayList<>(5));
        retEdges2.get(0).set(3,True);
        Assert.assertNotEquals(retEdges0,retEdges1);
        Assert.assertNotEquals(retEdges0,retEdges2);

        //Also no method to reset the inner edge of Edges in Graph
        graph.addEdge(p2,p3);
        Assert.assertNotEquals(graph.getEdges(),retEdges0);
    }

    /**
     * Testing strategy
     *
     * Partition the graph according to the size of Vertex and Edges: none, a few, many
     * The size of Vertex: a few, many
     * The size of Edges: none, a few, many
     */
    @Test
    public void getDistanceTest() {
        FriendshipGraph graph = new FriendshipGraph();

        Person p0 = new Person("0");
        Person p1 = new Person("1");
        Person p2 = new Person("2");
        Person p3 = new Person("3");
        Person p4 = new Person("4");
        Person p5 = new Person("5");
        Person p6 = new Person("6");

        graph.addVertex(p0);
        graph.addVertex(p1);

        //The graph with  a few vertex, and no edge
        Assert.assertEquals(0,graph.getDistance(p0,p0));
        Assert.assertEquals(-1,graph.getDistance(p0,p1));

        //The graph with many vertex, and no, a few, many edges
        graph.addVertex(p2);
        graph.addVertex(p3);
        graph.addVertex(p4);
        graph.addVertex(p5);
        graph.addVertex(p6);

        //The graph with none edge
        Assert.assertEquals(0, graph.getDistance(p0, p0));
        Assert.assertEquals(0, graph.getDistance(p2, p2));
        Assert.assertEquals(0, graph.getDistance(p4, p4));
        Assert.assertEquals(0, graph.getDistance(p6, p6));

        Assert.assertEquals(-1, graph.getDistance(p1, p2));
        Assert.assertEquals(-1, graph.getDistance(p3, p4));
        Assert.assertEquals(-1, graph.getDistance(p5, p6));
        Assert.assertEquals(-1, graph.getDistance(p6, p0));

        //The graph with a few edges
        graph.addEdge(p1, p2);
        graph.addEdge(p1, p5);
        graph.addEdge(p4, p5);
        graph.addEdge(p4, p6);

        Assert.assertEquals(4, graph.getDistance(p2, p6));
        Assert.assertEquals(2, graph.getDistance(p5, p6));
        Assert.assertEquals(-1, graph.getDistance(p0, p3));
        Assert.assertEquals(0, graph.getDistance(p4, p4));

        //The graph with many edges
        graph.addEdge(p0, p3);
        graph.addEdge(p0, p6);
        graph.addEdge(p1, p2);
        graph.addEdge(p1, p3);
        graph.addEdge(p1, p6);
        graph.addEdge(p2, p4);
        graph.addEdge(p3, p4);
        graph.addEdge(p3, p5);
        graph.addEdge(p4, p6);
        graph.addEdge(p5, p6);

        Assert.assertEquals(2, graph.getDistance(p0, p1));
        Assert.assertEquals(1, graph.getDistance(p5, p6));
        Assert.assertEquals(2, graph.getDistance(p2, p3));
        Assert.assertEquals(0, graph.getDistance(p1, p1));
    }
}
