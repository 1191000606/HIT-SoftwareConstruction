package P2;

public class Person {
    private final String name;

    // Abstraction function:
    //      name represent the label of the Person.
    // Representation invariant:
    //      name can not be repeated, changed, referred to other object.
    // Safety from rep exposure:
    //      name is private and final. Getter method don't use defensive copy for String is immutable.

    Person(String name) {
        this.name = name;
    }

    @Override
    public int hashCode() {
        return name != null ? name.hashCode() : -1;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Person p = (Person) o;

        return name != null ? name.equals(p.name) : p.name == null;
    }

    String getName() {
        return name;
    }
}
