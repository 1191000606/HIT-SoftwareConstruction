package P2;

import P1.graph.ConcreteVerticesGraph;
import P1.graph.Graph;

import java.util.*;
import java.util.concurrent.ConcurrentLinkedDeque;

public class FriendshipGraph {
    private final Graph<Person> graph = new ConcreteVerticesGraph<>();

    // Abstraction function:
    //      graph is directed and weight, representing the friendship graph.
    // Representation invariant:
    //      label can not be repeated.
    // Safety from rep exposure:
    //      graph is private and final. Getter method use defensive copy.

    /**
     * Get method using defensive copy.
     * @return the copy of graph.
     */
    public Graph<Person> getGraph() {
        Graph<Person> retGraph = new ConcreteVerticesGraph<>();

        for (Person person : graph.vertices()) {
            retGraph.add(person);
            Map<Person, Integer> personTargetMap = graph.targets(person);

            for (Map.Entry<Person, Integer> entry : personTargetMap.entrySet()) {
                retGraph.set(person, entry.getKey(), entry.getValue());
            }
        }

        return retGraph;
    }

    /**
     * add an vertex to graph. If it has already existed in graph, print error and exit with 1.
     *
     * @param p the given Person object, seen as a vertex.
     */
    public void addVertex(Person p) {
        if (!graph.add(p)) {
            System.err.println("Repeat to create " + p.getName());
            System.exit(1);
        }
    }

    /**
     * add an edge from p to q
     *
     * @param p Edge start vertex
     * @param q Edge end vertex
     */
    public void addEdge(Person p, Person q) {
        graph.set(p, q, 1);
    }

    /**
     * get the length of way from p to q. Define the num of edges of the way as its length
     *
     * @param p start vertex
     * @param q end vertex
     * @return If there exists many ways, return the min length. If there is no way, return -1
     */
    public int getDistance(Person p, Person q) {
        Set<Person> personSet = graph.vertices();
        Map<Person, Integer> distances = new HashMap<>(personSet.size());

        for (Person person : personSet) {
            distances.put(person, -1);
        }

        distances.put(p, 0);

        Queue<Person> queue = new ConcurrentLinkedDeque<>();

        queue.add(p);

        while (true) {
            Person head = queue.peek();

            if (head == q || head == null) {
                break;
            }

            int distanceOfHead = distances.get(head);

            for (Person person : graph.targets(head).keySet()) {
                if (distances.get(person) == -1) {
                    queue.add(person);
                    distances.put(person, distanceOfHead + 1);
                }
            }

            queue.poll();
        }

        return distances.get(q);
    }

    /**
     * client code
     *
     * @param args unused
     */
    public static void main(String[] args) {
        FriendshipGraph graph = new FriendshipGraph();
        Person rachel = new Person("Ross");
        Person ross = new Person("Ross");
        Person ben = new Person("Ben");
        Person kramer = new Person("Kramer");
        graph.addVertex(rachel);
        graph.addVertex(ross);
        graph.addVertex(ben);
        graph.addVertex(kramer);
        graph.addEdge(rachel, ross);
        graph.addEdge(ross, rachel);
        graph.addEdge(ross, ben);
        graph.addEdge(ben, ross);
        System.out.println(graph.getDistance(rachel, ross));
        System.out.println(graph.getDistance(rachel, ben));
        System.out.println(graph.getDistance(rachel, rachel));
        System.out.println(graph.getDistance(rachel, kramer));
    }
}
