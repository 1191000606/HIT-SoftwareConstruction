/* Copyright (c) 2015-2016 MIT 6.005 course staff, all rights reserved.
 * Redistribution of original or derived work requires permission of course staff.
 */
package P1.graph;

import java.util.*;

/**
 * An implementation of Graph.
 *
 * <p>PS2 instructions: you MUST use the provided rep.
 */
public class ConcreteVerticesGraph<L> implements Graph<L> {

    private final List<Vertex<L>> vertices = new ArrayList<>();

    // Abstraction function:
    //   vertices represent the vertex list of the graph
    //   <key,value> in vertex.edgeMap and <vertex,-1*value> in key.edgeMap represent:
    //      there is an edge from vertex to key if value is greater than zero.
    //      there is an edge from key to vertex if value is less than zero.
    // Representation invariant:
    //   if vertices contains all vertex occurs in EdgeMaps
    //   If <key,value> in vertex.edgeMap, key.edgeMap must contains <vertex,-1*value>
    // Safety from rep exposure:
    //   vertices is private and final. No getter method provided.
    //   No public method provides Vertex object which is mutable, but L. So vertex in vertices cannot be accessed.
    //   Even the arguments isn't Vertex object.

    /**
     * Construct an empty graph
     */
    public ConcreteVerticesGraph() {
    }

//    /**
//     * Check if vertices contains all vertex occurs in EdgeMaps and
//     * if all edges are represented  properly
//     */
//    private void checkRep() {
//        for (Vertex<L> vertex : vertices) {
//            HashMap<Vertex<L>, Integer> edgeMap = vertex.getEdgeMap();
//
//            for (Map.Entry<Vertex<L>, Integer> entry : edgeMap.entrySet()) {
//                assert vertices.contains(entry.getKey());
//                assert entry.getValue() == -1 * entry.getKey().getEdgeMap().get(entry.getKey());
//            }
//        }
//    }

    @Override
    public boolean add(L vertex) {
        if (findVertex(vertex) == null) {
            vertices.add(new Vertex<>(vertex));
            return true;
        }

        return false;
    }

    /**
     * Compare to specification in Graph.interface:
     * If weight is negative int, it will be seen as an edge form target to source weight -1*weight.
     *
     * @param source label of the source vertex
     * @param target label of the target vertex
     * @param weight weight of the weight which can be positive, negative int or zero
     * @return the previous weight of the edge, or zero if there was no such
     */
    @Override
    public int set(L source, L target, int weight) {
        Vertex<L> sourceVertex = findVertex(source);
        Vertex<L> targetVertex = findVertex(target);

        if (sourceVertex == null) {
            if (weight == 0)
                return 0;
            sourceVertex = new Vertex<>(source);
            vertices.add(sourceVertex);
        }

        if (targetVertex == null) {
            if (weight == 0)
                return 0;
            targetVertex = new Vertex<>(target);
            vertices.add(targetVertex);
        }

        int previousWeight = 0;

        if (sourceVertex.getEdgeMap().containsKey(targetVertex)) {
            previousWeight = sourceVertex.getEdgeMap().get(targetVertex);
        }

        sourceVertex.setEdgeMap(targetVertex, weight);

        return previousWeight;
    }

    @Override
    public boolean remove(L vertex) {
        Vertex<L> rmVertex = findVertex(vertex);

        if (rmVertex == null) {
            return false;
        }

        HashMap<Vertex<L>, Integer> rmEdges = rmVertex.getEdgeMap();

        for (Vertex<L> node : rmEdges.keySet()) {
            node.setEdgeMap(rmVertex, 0);
        }

        vertices.remove(rmVertex);

        return true;
    }

    @Override
    public Set<L> vertices() {
        Set<L> LSet = new HashSet<>();

        for (Vertex<L> node : vertices) {
            LSet.add(node.getName());
        }

        return LSet;
    }

    @Override
    public Map<L, Integer> sources(L target) {
        return links(target, -1);
    }

    @Override
    public Map<L, Integer> targets(L source) {
        return links(source, 1);
    }

    private Map<L, Integer> links(L vertex, int mode) {
        Map<L, Integer> retMap = new HashMap<>();
        Vertex<L> selectVertex = findVertex(vertex);

        if (selectVertex == null) {
            return retMap;
        }

        HashMap<Vertex<L>, Integer> selectEdgeMap = selectVertex.getEdgeMap();

        for (Map.Entry<Vertex<L>, Integer> entry : selectEdgeMap.entrySet()) {
            Vertex<L> node = entry.getKey();
            Integer weight = entry.getValue();

            if (mode == 1 && weight > 0) {
                retMap.put(node.getName(), weight);
            } else if (mode == -1 && weight < 0) {
                retMap.put(node.getName(), -1 * weight);
            }
        }

        return retMap;
    }

    /**
     * find whether a vertex exist in vertices.
     *
     * @param vertex the label of vertex
     * @return the reference of the vertex if existed, otherwise null.
     */
    private Vertex<L> findVertex(L vertex) {
        Vertex<L> retVertex = null;

        if (vertex != null) {
            for (Vertex<L> node : vertices) {
                if (vertex.equals(node.getName())) {
                    retVertex = node;
                }
            }
        } else {
            for (Vertex<L> node : vertices) {
                if (node.getName() == null) {
                    retVertex = node;
                }
            }
        }

        return retVertex;
    }

    /**
     * @return the labels of vertices and the source, target, weight of edges in Graph.
     */
    @Override
    public String toString() {
        StringBuilder retString = new StringBuilder("Graph: ");
        StringBuilder vertexString = new StringBuilder("\n\tVertex: ");
        StringBuilder edgesString = new StringBuilder("\n\tEdges: ");

        for (Vertex<L> node : vertices) {
            vertexString.append(node.getName());
            vertexString.append(" ");
        }

        HashMap<Vertex<L>, Integer> edgeMap;
        for (Vertex<L> node : vertices) {
            edgeMap = node.getEdgeMap();

            for (Map.Entry<Vertex<L>, Integer> entry : edgeMap.entrySet()) {
                if (entry.getValue() > 0) {
                    edgesString.append(node.getName());
                    edgesString.append("->");
                    edgesString.append(entry.getKey().getName());
                    edgesString.append(":");
                    edgesString.append(entry.getValue());
                    edgesString.append(" ");
                }
            }
        }

        retString.append(vertexString);
        retString.append(edgesString);
        return retString.toString();
    }
}

/**
 * Vertex have two attributes: name, edgeMap.
 * name is label of Vertex is cannot be changed.
 * edgeMap represent all edges with linked vertices and weights.
 * Mutable.
 * This class is internal to the rep of ConcreteVerticesGraph.
 *
 * <p>PS2 instructions: the specification and implementation of this class is
 * up to you.
 */
class Vertex<L> {
    private final L name;
    private final Map<Vertex<L>, Integer> edgeMap = new HashMap<>();

    // Abstraction function:
    //  Vertex has a name as label.
    //  For each <key, value> in edgeMap:
    //      if the value is greater than 0, it represents there is an edge weight value from Vertex to key.
    //      if the value is less than 0, it represents there is an edge weight absolute value from key to Vertex.
    // Representation invariant:
    //  The key in edgeMap is not null. The value in edgeMap is not zero.
    // Safety from rep exposure:
    //  name is private and final. As it is immutable, so getter method don't need defensive copy. No setter method.
    //  edgeMap is private, final. Getter method use defensive copy.

    Vertex(L name) {
        this.name = name;
    }

//    /**
//     * Check that the rep invariant is true. Usage: turn on assertion checking by passing -ea to Java
//     */
//    private void checkRep() {
//        for (Vertex<L> k : edgeMap.keySet()) {
//            assert k != null;
//            assert edgeMap.get(k) != 0;
//        }
//    }

    @Override
    public int hashCode() {
        return name != null ? name.hashCode() : -1;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Vertex<?> vertex = (Vertex<?>) o;

        return name != null ? name.equals(vertex.name) : vertex.name == null;
    }

    /**
     * @return the label of vertex. Not defensive copy as L is final and immutable.
     */
    L getName() {
        return name;
    }

    /**
     * @return the edges linked to vertex. Defensive copy.
     */
    HashMap<Vertex<L>, Integer> getEdgeMap() {
        return new HashMap<>(edgeMap);
    }

    /**
     * Set, update or delete the edge between this and the given vertex.
     * Notice: the edgeMap of the given vertex will also change.
     *
     * @param vertex the given vertex
     * @param weight if weight is zero, delete the edge with vertex if exists. Otherwise set or update the edge with vertex.
     */
    void setEdgeMap(Vertex<L> vertex, int weight) {
        if (weight != 0) {
            edgeMap.put(vertex, weight);
            vertex.edgeMap.put(this, -1 * weight);
        } else {
            edgeMap.remove(vertex);
            vertex.edgeMap.remove(this);
        }

    }

    /**
     * @return String contains the label of vertex, labels of all vertices linked to vertex and the weight of the edges.
     */
    @Override
    public String toString() {
        StringBuilder retString = new StringBuilder();
        StringBuilder inEdges = new StringBuilder("\n\tinEdges: ");
        StringBuilder outEdges = new StringBuilder("\n\toutEdges: ");

        for (Map.Entry<Vertex<L>, Integer> entry : edgeMap.entrySet()) {
            Vertex<L> vertex = entry.getKey();
            int weight = entry.getValue();

            if (weight < 0) {
                inEdges.append(vertex.name);
                inEdges.append("->");
                inEdges.append(name);
                inEdges.append(":");
                inEdges.append(-1 * weight);
                inEdges.append(" ");
            }

            if (weight > 0) {
                outEdges.append(name);
                outEdges.append("->");
                outEdges.append(vertex.name);
                outEdges.append(":");
                outEdges.append(weight);
                outEdges.append(" ");
            }
        }

        retString.append(name);
        retString.append(inEdges);
        retString.append(outEdges);

        return retString.toString();
    }
}
