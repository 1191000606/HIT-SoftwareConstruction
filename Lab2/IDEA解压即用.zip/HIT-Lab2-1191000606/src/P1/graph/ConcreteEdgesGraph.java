/* Copyright (c) 2015-2016 MIT 6.005 course staff, all rights reserved.
 * Redistribution of original or derived work requires permission of course staff.
 */
package P1.graph;

import java.util.*;

/**
 * An implementation of Graph.
 *
 * <p>PS2 instructions: you MUST use the provided rep.
 */
public class ConcreteEdgesGraph<L> implements Graph<L> {

    private final Set<L> vertices = new HashSet<>();
    private final List<Edge<L>> edges = new ArrayList<>();

    // Abstraction function:
    //      vertices are the set of all vertex labels in graph.
    //      edges represents all the edges in the graph. It contains the labels of the source and target vertex and weight.
    // Representation invariant:
    //      all source and target vertex should exist in vertices.
    //      the weight of all edges must be positive int.
    // Safety from rep exposure:
    //      vertices and edges are private and final. So they can't be accessed directly outside.
    //      All return are immutable or collection of immutable type.

    public ConcreteEdgesGraph() {
    }

//    private void checkRep() {
//        for (Edge<L> edge : edges) {
//            assert vertices.contains(edge.getSource());
//            assert vertices.contains(edge.getTarget());
//            assert edge.getWeight() > 0;
//        }
//    }

    @Override
    public boolean add(L vertex) {
        if (vertices.contains(vertex)) {
            return false;
        } else {
            vertices.add(vertex);
            return true;
        }
    }

    /**
     * Compare to specification in Graph.interface:
     * If weight is negative int, it will be seen as an edge form target to source weight -1*weight.
     *
     * @param source label of the source vertex
     * @param target label of the target vertex
     * @param weight weight of the weight which can be positive, negative int or zero
     * @return the previous weight of the edge, or zero if there was no such
     */
    @Override
    public int set(L source, L target, int weight) {
        if (weight == 0) {
            if (!vertices.contains(source) || !vertices.contains(target)) {
                return 0;
            }

            Map<L, Integer> vertexLinkedSource = links(source);
            int formerWeight = 0;

            if (vertexLinkedSource.containsKey(target)) {
                formerWeight = vertexLinkedSource.get(target);


                removeEdge(source, target, formerWeight);
            }
            return formerWeight;

        } else {
            if (weight < 0) {
                L tmp = source;
                source = target;
                target = tmp;
                weight = -1 * weight;
            }

            if (!vertices.contains(source) || !vertices.contains(target)) {
                vertices.add(source);
                vertices.add(target);
                edges.add(new Edge<>(source, target, weight));
                return 0;
            }

            Map<L, Integer> vertexLinkedSource = links(source);
            int formerWeight = 0;

            if (vertexLinkedSource.containsKey(target)) {
                formerWeight = vertexLinkedSource.get(target);
                removeEdge(source, target, formerWeight);
            }

            edges.add(new Edge<>(source, target, weight));
            return formerWeight;
        }
    }

    @Override
    public boolean remove(L vertex) {
        if (!vertices.contains(vertex))
            return false;

        Map<L, Integer> linkedVertexMap = links(vertex);

        for (Map.Entry<L, Integer> entry : linkedVertexMap.entrySet()) {
            removeEdge(vertex, entry.getKey(), entry.getValue());
        }

        vertices.remove(vertex);
        return true;
    }

    @Override
    public Set<L> vertices() {
        return new HashSet<>(vertices);
    }

    @Override
    public Map<L, Integer> sources(L target) {
        return findLinkedVertex(target, -1);
    }

    @Override
    public Map<L, Integer> targets(L source) {
        return findLinkedVertex(source, 1);
    }

    private Map<L, Integer> links(L vertex) {
        return findLinkedVertex(vertex, 0);
    }

    /**
     * Given a vertex and find vertex linked to it. According to input mode, the return vertex can be limited to with edges from or to given vertex.
     * Return a map of found vertex and weight.
     *
     * @param vertex the given vertex.
     * @param mode   If mode=1, only return the vertex with edge from given vertex. If mode=-1,only return to. If mode=0,return all.
     * @return the vertex linked to the given vertex and weight.
     */
    private Map<L, Integer> findLinkedVertex(L vertex, int mode) {
        Map<L, Integer> retMap = new HashMap<>();

        if (!vertices.contains(vertex))
            return retMap;

        Map<L, Integer> sourceMap = new HashMap<>();
        Map<L, Integer> targetMap = new HashMap<>();

        for (Edge<L> edge : edges) {
            if (vertex != null) {
                if (vertex.equals(edge.getSource())) {
                    targetMap.put(edge.getTarget(), edge.getWeight());
                } else if (vertex.equals(edge.getTarget())) {
                    sourceMap.put(edge.getSource(), edge.getWeight());
                }
            } else {
                if (edge.getSource() == null) {
                    targetMap.put(edge.getTarget(), edge.getWeight());
                } else if (edge.getTarget() == null) {
                    sourceMap.put(edge.getSource(), edge.getWeight());
                }
            }
        }

        if (mode == 0) {
            retMap.putAll(sourceMap);
            retMap.putAll(targetMap);
        } else if (mode == 1) {
            retMap.putAll(targetMap);
        } else if (mode == -1) {
            retMap.putAll(sourceMap);
        }

        return retMap;
    }

    private void removeEdge(L vertex0, L vertex1, int weight) {
        Edge<L> edge0 = new Edge<>(vertex0, vertex1, weight);
        Edge<L> edge1 = new Edge<>(vertex1, vertex0, weight);

        for (Edge<L> edge : edges) {
            if (edge.equals(edge0) || edge.equals(edge1)) {
                edges.remove(edge);
                return;
            }
        }

    }

    /**
     * @return the labels of vertices and the source, target, weight of edges in Graph.
     */
    @Override
    public String toString() {
        StringBuilder retString = new StringBuilder("Graph: ");
        StringBuilder vertexString = new StringBuilder("\n\tVertex: ");
        StringBuilder edgesString = new StringBuilder("\n\tEdges: ");

        for (L node : vertices) {
            vertexString.append(node);
            vertexString.append(" ");
        }

        for (Edge<L> edge : edges) {
            edgesString.append(edge.getSource());
            edgesString.append("->");
            edgesString.append(edge.getTarget());
            edgesString.append(":");
            edgesString.append(edge.getWeight());
            edgesString.append(" ");
        }

        retString.append(vertexString);
        retString.append(edgesString);

        return retString.toString();
    }

}

/**
 * Edge has three fields:
 * source as the label of the source vertex of the edge,
 * target as the label of the target vertex of the edge,
 * weight as the weight of the edge.
 * Immutable.
 * This class is internal to the rep of ConcreteEdgesGraph.
 *
 * <p>PS2 instructions: the specification and implementation of this class is
 * up to you.
 */
class Edge<L> {
    private final L source;
    private final L target;
    private final int weight;

    // Abstraction function:
    //   source and target represent the labels of the source and target vertex of the edge. weight represents the edge weight.
    // Representation invariant:
    //   weight is positive int.
    // Safety from rep exposure:
    //   All fields are private and final.
    //   Because Edge class is immutable, so no setter method provided. And other methods also don't changed them.
    //   Getter method don't use defensive copy because L and int are immutable and can't be changed.
    //   So they couldn't be accessed, changed or refer to other objects.

    /**
     * Constructor method
     * @param source the source label of edge if weight is positive, otherwise target.
     * @param target the target label of edge if weight is positive, otherwise source.
     * @param weight the weight of edge, should not be zero. If it's negative, it will multi -1 and change the direction of the edge.
     */
    Edge(L source, L target, int weight) {
        if (weight > 0) {
            this.source = source;
            this.target = target;
            this.weight = weight;
        } else {
            this.source = target;
            this.target = source;
            this.weight = weight * -1;
        }
    }

//    /**
//     * check if weight is greater than zero.
//     */
//    void checkRep() {
//        assert weight > 0;
//    }

    /**
     * Getter method for source label. No defensive copy.
     *
     * @return the reference of the source label.
     */
    L getSource() {
        return source;
    }

    /**
     * Getter method for target label. No defensive copy.
     *
     * @return the reference of the target label.
     */
    L getTarget() {
        return target;
    }

    /**
     * Getter method for weight.
     *
     * @return the weight of edge.
     */
    int getWeight() {
        return weight;
    }

    @Override
    public int hashCode() {
        int hashCode = weight;

        if (source != null) {
            hashCode += source.hashCode();
        }

        if (target != null) {
            hashCode += target.hashCode();
        }

        return hashCode;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;

        if (o == null || o.getClass() != getClass())
            return false;

        Edge<?> oToEdge = (Edge<?>) o;

        if (weight != oToEdge.weight)
            return false;

        if (source != null) {
            if (!source.equals(oToEdge.source)) {
                return false;
            }
        } else {
            if (oToEdge.source != null) {
                return false;
            }
        }

        if (target != null) {
            return target.equals(oToEdge.target);
        } else {
            return oToEdge.target == null;
        }
    }

    /**
     * @return the source label, target label and weight of the edge.
     */
    @Override
    public String toString() {
        return source + "->" + target + ":" + weight;
    }

}
