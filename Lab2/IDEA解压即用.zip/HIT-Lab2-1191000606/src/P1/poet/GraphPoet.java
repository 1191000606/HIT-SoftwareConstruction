/* Copyright (c) 2015-2016 MIT 6.005 course staff, all rights reserved.
 * Redistribution of original or derived work requires permission of course staff.
 */
package P1.poet;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

import java.util.*;

import P1.graph.Graph;

/**
 * A graph-based poetry generator.
 *
 * <p>GraphPoet is initialized with a corpus of text, which it uses to derive a
 * word affinity graph.
 * Vertices in the graph are words. Words are defined as non-empty
 * case-insensitive strings of non-space non-newline characters. They are
 * delimited in the corpus by spaces, newlines, or the ends of the file.
 * Edges in the graph count adjacency's: the number of times "w1" is followed by
 * "w2" in the corpus is the weight of the edge from w1 to w2.
 *
 * <p>For example, given this corpus:
 * <pre>    Hello, HELLO, hello, goodbye!    </pre>
 * <p>the graph would contain two edges:
 * <ul><li> ("hello,") -> ("hello,")   with weight 2
 *     <li> ("hello,") -> ("goodbye!") with weight 1 </ul>
 * <p>where the vertices represent case-insensitive {@code "hello,"} and
 * {@code "goodbye!"}.
 *
 * <p>Given an input string, GraphPoet generates a poem by attempting to
 * insert a bridge word between every adjacent pair of words in the input.
 * The bridge word between input words "w1" and "w2" will be some "b" such that
 * w1 -> b -> w2 is a two-edge-long path with maximum-weight weight among all
 * the two-edge-long paths from w1 to w2 in the affinity graph.
 * If there are no such paths, no bridge word is inserted.
 * In the output poem, input words retain their original case, while bridge
 * words are lower case. The whitespace between every word in the poem is a
 * single space.
 *
 * <p>For example, given this corpus:
 * <pre>    This is a test of the Sugar Omni Theater sound system.    </pre>
 * <p>on this input:
 * <pre>    Test the system.    </pre>
 * <p>the output poem would be:
 * <pre>    Test of the system.    </pre>
 *
 * <p>PS2 instructions: this is a required ADT class, and you MUST NOT weaken
 * the required specifications. However, you MAY strengthen the specifications
 * and you MAY add additional methods.
 * You MUST use Graph in your rep, but otherwise the implementation of this
 * class is up to you.
 */
public class GraphPoet {

    private final Graph<String> graph = Graph.empty();

    // Abstraction function:
    //  graph represents the graph of the poet. Each words occurring in poet is a vertex of Graph. Vertex are the String
    //  of characters separated by blank, line-termination characters or the end of the Poet but not including them. The
    //  source and target of edge represent source is followed by target. The weight represent how many times.
    // Representation invariant:
    //  graph must contain all words occurring in Poet. And words are turned into lowercase. No blank, line-termination characters
    //  in it.
    // Safety from rep exposure:
    //  Graph is private and final. No Getter or Setter method provided. Only one method return the String representation
    //  of the Graph Poet.

    /**
     * Create a new poet with the graph from corpus (as described above).
     *
     * @param corpus text file from which to derive the poet's affinity graph
     * @throws IOException if the corpus file cannot be found or read.
     */
    public GraphPoet(File corpus) throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader(corpus));
        String poetLine;
        List<String> poetStrings = new ArrayList<>();

        while ((poetLine = reader.readLine()) != null) {
            poetStrings.addAll(Arrays.asList(poetLine.split(" ")));
        }

        int length = poetStrings.size();

        switch (length) {
            case 1:
                graph.add(poetStrings.get(0));
            case 0:
                return;
        }

        String formerWord = poetStrings.get(0).toLowerCase(Locale.ROOT);
        String currentWord;
        Integer formerWeight;
        graph.add(formerWord);

        for (int i = 1; i < length; i++) {
            currentWord = poetStrings.get(i).toLowerCase(Locale.ROOT);
            if (graph.add(currentWord)) {
                graph.set(formerWord, currentWord, 1);
            } else {
                formerWeight = graph.sources(currentWord).get(formerWord);
                graph.set(formerWord, currentWord, formerWeight == null ? 1 : formerWeight + 1);
            }
            formerWord = currentWord;
        }
    }

//    /**
//     * Check if graph contain all words' lowercase occurring in Poet.
//     * if words don't contain blank or line-termination characters.
//     *
//     * @param corpus text file from which to derive the poet's affinity graph
//     * @throws IOException if the corpus file cannot be found or read.
//     */
//    private void checkRep(File corpus) throws IOException {
//        BufferedReader reader = new BufferedReader(new FileReader(corpus));
//        String poetLine;
//        String[] poetStrings;
//        Set<String> vertexSet = graph.vertices();
//
//        while ((poetLine = reader.readLine()) != null) {
//            poetStrings = poetLine.split(" ");
//
//            int length = poetStrings.length;
//
//            if (length == 0)
//                continue;
//
//            for (String word : poetStrings) {
//                assert vertexSet.contains(word.toLowerCase(Locale.ROOT));
//                assert !word.contains(" ");
//                assert !word.contains("\n");
//                assert !word.contains("\r");
//            }
//        }
//    }

    /**
     * Generate a poem.
     *
     * @param input string from which to create the poem
     * @return poem (as described above)
     */
    public String poem(String input) {
        String[] inputWords = input.split(" ");
        int length = inputWords.length;

        if (length == 1) {
            return input;
        }

        Set<String> vertices = graph.vertices();
        StringBuilder retString = new StringBuilder();
        String currentString;
        String nextString;
        Map<String, Integer> nextEdgeMap, currentEdgeMap;
        String linkString = null;
        int currentWeight;
        int maxWeight;

        for (int i = 0; i < length - 1; i++) {
            retString.append(inputWords[i]);
            retString.append(" ");

            if (vertices.contains(inputWords[i].toLowerCase(Locale.ROOT))) {
                if (vertices.contains(inputWords[i + 1].toLowerCase(Locale.ROOT))) {
                    currentString = inputWords[i].toLowerCase(Locale.ROOT);
                    nextString = inputWords[i + 1].toLowerCase(Locale.ROOT);
                    currentEdgeMap = graph.targets(currentString);
                    nextEdgeMap = graph.sources(nextString);
                    maxWeight = 0;

                    for (String key : currentEdgeMap.keySet()) {
                        if (nextEdgeMap.containsKey(key)) {
                            currentWeight = currentEdgeMap.get(key) + nextEdgeMap.get(key);
                            if (currentWeight > maxWeight) {
                                maxWeight = currentWeight;
                                linkString = key;
                            }
                        }
                    }

                    if (maxWeight != 0) {
                        retString.append(linkString);
                        retString.append(" ");
                    }
                } else {
                    if (i != length - 2) {
                        retString.append(inputWords[i + 1]);
                        retString.append(" ");
                        i++;
                    }
                }
            }
        }

        retString.append(inputWords[length - 1]);

        return retString.toString();
    }

    /**
     * @return all words and edges information as a String.
     */
    @Override
    public String toString() {
        StringBuilder retString = new StringBuilder("Graph of Poet: ");
        StringBuilder vertexString = new StringBuilder("\n\tVertex: ");
        StringBuilder edgeString = new StringBuilder("\n\tEdges: ");

        for (String vertex : graph.vertices()) {
            vertexString.append(vertex);
            vertexString.append(" ");

            Map<String, Integer> targetMap = graph.targets(vertex);

            for (Map.Entry<String, Integer> entry : targetMap.entrySet()) {
                edgeString.append(vertex);
                edgeString.append("->");
                edgeString.append(entry.getKey());
                edgeString.append(":");
                edgeString.append(entry.getValue());
                edgeString.append(" ");
            }
        }

        retString.append(vertexString);
        retString.append(edgeString);

        return retString.toString();
    }

}
