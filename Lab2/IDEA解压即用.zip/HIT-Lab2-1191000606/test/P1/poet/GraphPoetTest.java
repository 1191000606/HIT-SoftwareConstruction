/* Copyright (c) 2015-2016 MIT 6.005 course staff, all rights reserved.
 * Redistribution of original or derived work requires permission of course staff.
 */
package P1.poet;

import static org.junit.Assert.*;

import org.junit.Test;

import java.io.File;
import java.io.IOException;

/**
 * Tests for GraphPoet.
 */
public class GraphPoetTest {

    @Test(expected = AssertionError.class)
    public void testAssertionsEnabled() {
        assert false; // make sure assertions are enabled with VM argument: -ea
    }

    /**
     * Test whether constructor method works properly.
     *
     * Testing Strategy
     *
     * Partition the input files as follows: empty, contains one line, contains many lines.
     */
    @Test
    public void GraphPoetConstructorTest() {
        GraphPoet emptyGraphPoet;
        GraphPoet oneLineGraphPoet;
        GraphPoet manyLinesGraphPoet;

        try {
            emptyGraphPoet = new GraphPoet(new File("test/P1/poet/empty.txt"));
            oneLineGraphPoet = new GraphPoet(new File("test/P1/poet/oneLine.txt"));
            manyLinesGraphPoet = new GraphPoet(new File("test/P1/poet/manyLines.txt"));

            assertEquals("Graph of Poet: \n\tVertex: \n\tEdges: ", emptyGraphPoet.toString());
            assertEquals("Graph of Poet: \n\tVertex: the a test mugar theater of sound this is omni system. \n\tEdges: the->mugar:1 a->test:1 test->of:1 mugar->omni:1 theater->sound:1 of->the:1 sound->system.:1 this->is:1 is->a:1 omni->theater:1 ", oneLineGraphPoet.toString());
            assertEquals("Graph of Poet: \n\tVertex: hello, chen a study pass, hard. in year finally i harbin technology. am good coder. month and of yifan, institute day become \n\tEdges: hello,->i:1 chen->yifan,:1 a->good:1 study->hard.:1 study->in:1 pass,->i:1 hard.->finally:1 in->harbin:1 year->pass,:1 finally->i:1 i->study:2 i->am:1 i->become:1 harbin->institute:1 technology.->day:1 am->chen:1 good->coder.:1 month->pass,:1 and->month:1 and->year:1 and->day:1 of->technology.:1 yifan,->i:1 institute->of:1 day->pass,:1 become->a:1 ", manyLinesGraphPoet.toString());

        } catch (IOException ioException) {
            ioException.printStackTrace();
        }
    }

    /**
     * Test whether poem method works properly.
     *
     * Testing Strategy
     *
     * Partition the graph as simple and complex.
     */
    @Test
    public void poemTest() {
        try {
            GraphPoet simpleGraph = new GraphPoet(new File("test/P1/poet/oneLine.txt"));
            GraphPoet complexGraph = new GraphPoet(new File("test/P1/poet/complexLines.txt"));
            String simpleString = "Test the system.";
            String complexString = "Chen I hard. I coder\n";

            assertEquals("Test of the system.", simpleGraph.poem(simpleString));
            assertEquals("Chen ! I study hard. finally I coder\n", complexGraph.poem(complexString));
        } catch (IOException ioException) {
            ioException.printStackTrace();
        }
    }

    /**
     * Test whether toString method works properly.
     *
     * Testing Strategy
     *
     * Partition the input files as follows: empty, contains one line, contains many lines.
     */
    @Test
    public void toStringTest()
    {
        GraphPoet emptyGraphPoet;
        GraphPoet oneLineGraphPoet;
        GraphPoet manyLinesGraphPoet;

        try {
            emptyGraphPoet = new GraphPoet(new File("test/P1/poet/empty.txt"));
            oneLineGraphPoet = new GraphPoet(new File("test/P1/poet/oneLine.txt"));
            manyLinesGraphPoet = new GraphPoet(new File("test/P1/poet/manyLines.txt"));

            assertEquals("Graph of Poet: \n\tVertex: \n\tEdges: ", emptyGraphPoet.toString());
            assertEquals("Graph of Poet: \n\tVertex: the a test mugar theater of sound this is omni system. \n\tEdges: the->mugar:1 a->test:1 test->of:1 mugar->omni:1 theater->sound:1 of->the:1 sound->system.:1 this->is:1 is->a:1 omni->theater:1 ", oneLineGraphPoet.toString());
            assertEquals("Graph of Poet: \n\tVertex: hello, chen a study pass, hard. in year finally i harbin technology. am good coder. month and of yifan, institute day become \n\tEdges: hello,->i:1 chen->yifan,:1 a->good:1 study->hard.:1 study->in:1 pass,->i:1 hard.->finally:1 in->harbin:1 year->pass,:1 finally->i:1 i->study:2 i->am:1 i->become:1 harbin->institute:1 technology.->day:1 am->chen:1 good->coder.:1 month->pass,:1 and->month:1 and->year:1 and->day:1 of->technology.:1 yifan,->i:1 institute->of:1 day->pass,:1 become->a:1 ", manyLinesGraphPoet.toString());

        } catch (IOException ioException) {
            ioException.printStackTrace();
        }
    }
}
