/* Copyright (c) 2015-2016 MIT 6.005 course staff, all rights reserved.
 * Redistribution of original or derived work requires permission of course staff.
 */
package P1.graph;

import static org.junit.Assert.*;

import java.util.*;

import org.junit.Test;

/**
 * Tests for instance methods of Graph.
 *
 * <p>PS2 instructions: you MUST NOT add constructors, fields, or non-@Test
 * methods to this class, or change the spec of {@link #emptyInstance()}.
 * Your tests MUST only obtain Graph instances by calling emptyInstance().
 * Your tests MUST NOT refer to specific concrete implementations.
 */
public abstract class GraphInstanceTest {

    // Testing strategy
    //   Get Graph object by using method emptyInstance, then test other methods in Graph.interface

    /**
     * Overridden by implementation-specific test classes.
     *
     * @return a new empty graph of the particular implementation being tested
     */
    public abstract Graph<String> emptyInstance();

    @Test(expected = AssertionError.class)
    public void testAssertionsEnabled() {
        assert false; // make sure assertions are enabled with VM argument: -ea
    }

    @Test
    public void testInitialVerticesEmpty() {
        assertEquals("expected new graph to have no vertices",
                Collections.emptySet(), emptyInstance().vertices());
    }

    /**
     * Test whether add method works properly.
     *
     * Testing Strategy
     *
     * Partition input String as follows: null, empty, Chinese characters.
     * To test whether vertices are successfully added to graph and the return is excepted.
     */
    @Test
    public void addTest() {
        Graph<String> graph = emptyInstance();

        assertTrue(graph.add(null));
        assertTrue(graph.add("陈一帆"));
        assertTrue(graph.add(""));
        assertFalse(graph.add(null));
        assertFalse(graph.add("陈一帆"));
        assertFalse(graph.add(""));

        Set<String> vertices = new HashSet<>();
        vertices.add(null);
        vertices.add("陈一帆");
        vertices.add("");
        assertEquals(vertices, graph.vertices());
    }

    /**
     * Test whether set method works properly.
     *
     * Testing strategy
     *
     * Covers:
     * weight is 0, positive int.
     * source exists in graph.vertices or not.
     * target exist in graph.vertices or not.
     * source is null or not.
     * target is null or not.
     */
    @Test
    public void setTest() {
        Graph<String> graph = emptyInstance();
        Set<String> stringSet = new HashSet<>();
        Map<String, Integer> linkMap = new HashMap<>();

        //source is null, target is not null, Both of them don't exist in Graph. Weight is zero.
        graph.set(null, "Target", 0);
        assertEquals(stringSet,graph.vertices());

        //source is null, target is not null. Both of them don't exist in Graph. Weight is positive int.
        graph.set(null, "Target", 10);
        stringSet.add("Target");
        stringSet.add(null);
        linkMap.put("Target", 10);
        assertEquals(stringSet, graph.vertices());
        assertEquals(linkMap, graph.targets(null));
        linkMap.remove("Target");
        linkMap.put(null, 10);
        assertEquals(linkMap, graph.sources("Target"));

        //source is not null, target is null. Both of them exist in Graph. Weight is zero.
        graph.set("Target", null, 0);
        assertEquals(stringSet, graph.vertices());
        linkMap.remove(null);
        assertEquals(linkMap, graph.sources("Target"));
        assertEquals(linkMap, graph.targets(null));
    }

    /**
     * Test whether remove method works properly.
     *
     * Testing strategy
     *
     * Partition the input labels as follows:
     * label is null or not.
     * label exists or not.
     * Linked Edges are none, few or many.
     */
    @Test
    public void removeTest() {
        Graph<String> graph = emptyInstance();
        Set<String> stringSet = new HashSet<>();

        //remove null label vertex which doesn't exist.
        assertFalse(graph.remove(null));

        //remove not null label vertex which doesn't exist.
        assertFalse(graph.remove("0"));

        graph.add("0");
        graph.add("1");
        graph.add("2");
        graph.add("3");

        //remove not null label vertex which exists, no edges from or to it.
        assertTrue(graph.remove("0"));
        stringSet.add("1");
        stringSet.add("2");
        stringSet.add("3");
        assertEquals(stringSet, graph.vertices());

        //remove not null label vertex which exists, few edges from and to it.
        graph.set("2", "1", 1);
        graph.set("1", "3", 1);
        assertTrue(graph.remove("1"));

        //remove null label vertex which exists, many edges from and to it.
        graph.add(null);
        graph.add("4");
        graph.add("5");
        graph.add("6");
        graph.add("7");
        graph.set(null, "2", 2);
        graph.set("3", null, 3);
        graph.set("4", null, 4);
        graph.set(null, "5", 5);
        graph.set("6", null, 6);
        graph.set(null, "7", 7);
        assertTrue(graph.remove(null));
        stringSet.remove("1");
        stringSet.remove(null);
        stringSet.add("4");
        stringSet.add("5");
        stringSet.add("6");
        stringSet.add("7");
        assertEquals(stringSet, graph.vertices());
    }

    /**
     * Test whether vertices method works properly.
     *
     * Testing Strategy
     *
     * Partition the vertices according to its size and vertex label kinds inside.
     * Covers:
     * size is zero, a little and large
     * labels are null, empty, Chinese Character.
     */
    @Test
    public void verticesTest() {
        Graph<String> graph = emptyInstance();
        Set<String> stringSet = new HashSet<>();

        //size is zero, no vertex in it
        assertEquals(stringSet, graph.vertices());

        graph.add(null);
        graph.add("");
        stringSet.add(null);
        stringSet.add("");
        //size is a little, vertex labels are null and empty
        assertEquals(stringSet, graph.vertices());

        graph.add("陈一帆");
        graph.add("0");
        graph.add("1");
        graph.add("2");
        graph.add("3");
        graph.add("4");
        graph.add("5");
        graph.add("6");
        stringSet.add("陈一帆");
        stringSet.add("0");
        stringSet.add("1");
        stringSet.add("2");
        stringSet.add("3");
        stringSet.add("4");
        stringSet.add("5");
        stringSet.add("6");
        assertEquals(stringSet, graph.vertices());
    }

    /**
     * Test whether sources method works properly.
     *
     * Testing Strategy
     *
     * Covers:
     * target exist or not.
     * sources are null, empty, Chinese character.
     * num of sources are zero, a few, many.
     */
    @Test
    public void sourcesTest() {
        Graph<String> graph = emptyInstance();
        Map<String, Integer> exceptMap = new HashMap<>();

        graph.add(null);
        graph.add("");
        graph.set("", null, 10);

        //target doesn't exist.
        assertEquals(exceptMap, graph.sources("陈一帆"));

        //target exists and label is null, with one edge to it.
        exceptMap.put("", 10);
        assertEquals(exceptMap, graph.sources(null));

        //target exist and label is empty, with no edge to it.
        exceptMap.remove("");
        assertEquals(exceptMap, graph.sources(""));

        //target exist and label is Chinese Character, with many edges to it.
        graph.add("陈一帆");
        graph.add("0");
        graph.add("1");
        graph.add("2");
        graph.add("3");
        graph.add("4");
        graph.add("5");
        graph.add("6");
        graph.add("7");
        graph.add("8");
        graph.add("9");
        graph.set(null, "陈一帆", 100);
        graph.set("0", "陈一帆", 0);
        graph.set("1", "陈一帆", 1);
        graph.set("2", "陈一帆", 2);
        graph.set("3", "陈一帆", 3);
        graph.set("4", "陈一帆", 4);
        graph.set("5", "陈一帆", 5);
        graph.set("6", "陈一帆", 6);
        graph.set("陈一帆", "7", 7);
        graph.set("陈一帆", "8", 8);
        graph.set("陈一帆", "9", 9);
        exceptMap.put("1", 1);
        exceptMap.put("2", 2);
        exceptMap.put("3", 3);
        exceptMap.put("4", 4);
        exceptMap.put("5", 5);
        exceptMap.put("6", 6);
        exceptMap.put(null, 100);
        assertEquals(exceptMap, graph.sources("陈一帆"));
    }

    /**
     * Test whether targets method works properly.
     *
     * Testing Strategy
     *
     * Covers:
     * source exist or not.
     * targets are null, empty, Chinese character.
     * num of targets are zero, a few, many.
     */
    @Test
    public void targetsTest() {
        Graph<String> graph = emptyInstance();
        Map<String, Integer> exceptMap = new HashMap<>();

        graph.add(null);
        graph.add("");
        graph.set("", null, 10);

        //source doesn't exist.
        assertEquals(exceptMap, graph.targets("陈一帆"));

        //source exists and label is empty, with one edge from it.
        exceptMap.put(null, 10);
        assertEquals(exceptMap, graph.targets(""));

        //source exist and label is null, with no edge from it.
        exceptMap.remove(null);
        assertEquals(exceptMap, graph.targets(null));

        //sources exist and label is Chinese Character, with many edges from it.
        graph.add("陈一帆");
        graph.add("0");
        graph.add("1");
        graph.add("2");
        graph.add("3");
        graph.add("4");
        graph.add("5");
        graph.add("6");
        graph.add("7");
        graph.add("8");
        graph.add("9");
        graph.set("陈一帆", null, 100);
        graph.set("陈一帆", "0", 0);
        graph.set("陈一帆", "1", 1);
        graph.set("陈一帆", "2", 2);
        graph.set("陈一帆", "3", 3);
        graph.set("陈一帆", "4", 4);
        graph.set("陈一帆", "5", 5);
        graph.set("陈一帆", "6", 6);
        graph.set("7", "陈一帆", 7);
        graph.set("8", "陈一帆", 8);
        graph.set("9", "陈一帆", 9);

        exceptMap.put("1", 1);
        exceptMap.put("2", 2);
        exceptMap.put("3", 3);
        exceptMap.put("4", 4);
        exceptMap.put("5", 5);
        exceptMap.put("6", 6);
        exceptMap.put(null, 100);
        assertEquals(exceptMap, graph.targets("陈一帆"));
    }
}
