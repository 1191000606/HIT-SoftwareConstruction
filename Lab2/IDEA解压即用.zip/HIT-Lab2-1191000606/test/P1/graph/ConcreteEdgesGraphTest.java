/* Copyright (c) 2015-2016 MIT 6.005 course staff, all rights reserved.
 * Redistribution of original or derived work requires permission of course staff.
 */
package P1.graph;

import static org.junit.Assert.*;

import org.junit.Test;

/**
 * Tests for ConcreteEdgesGraph.
 *
 * This class runs the GraphInstanceTest tests against ConcreteEdgesGraph, as
 * well as tests for that particular implementation.
 *
 * Tests against the Graph spec should be in GraphInstanceTest.
 */
public class ConcreteEdgesGraphTest extends GraphInstanceTest {

    /*
     * Provide a ConcreteEdgesGraph for tests in GraphInstanceTest.
     */
    @Override
    public Graph<String> emptyInstance() {
        return new ConcreteEdgesGraph<>();
    }

    /*
     * Testing ConcreteEdgesGraph...
     */

    /**
     * Test whether toString method works properly
     *
     * Testing strategy
     * Partition the graph `according to the num of Vertex and Edges.
     * Covers:  Vertices are none, few, many.
     * Edges are none, few, many.
     */
    @Test
    public void graphToStringTest() {
        Graph<String> graph = new ConcreteEdgesGraph<>();

        //Vertices and Edges are none.
        assertEquals("Graph: \n\tVertex: \n\tEdges: ", graph.toString());

        //Vertices are few and edges are none.
        graph.add("0");
        graph.add("1");
        assertEquals("Graph: \n\tVertex: 0 1 \n\tEdges: ", graph.toString());

        //Vertices are few and edges are few.
        graph.set("1", "0", 2);
        assertEquals("Graph: \n\tVertex: 0 1 \n\tEdges: 1->0:2 ", graph.toString());

        //Vertices are many and edges are few.
        graph.add("2");
        graph.add("3");
        graph.add("4");
        graph.add("5");
        graph.add("6");
        assertEquals("Graph: \n\tVertex: 0 1 2 3 4 5 6 \n\tEdges: 1->0:2 ", graph.toString());

        //Vertices are many and edges are many.
        graph.set("0", "1", 0);
        graph.set("0", "3", 0);
        graph.set("1", "2", -3);
        graph.set("3", "1", 4);
        graph.set("4", "1", -5);
        graph.set("4", "2", 6);
        graph.set("2", "5", -7);
        graph.set("3", "5", 8);
        graph.set("6", "3", -9);
        graph.set("6", "4", 10);
        graph.set("5", "6", 11);
        graph.set("5", "6", -11);
        assertEquals("Graph: \n\tVertex: 0 1 2 3 4 5 6 \n\tEdges: 2->1:3 3->1:4 1->4:5 4->2:6 5->2:7 3->5:8 3->6:9 6->4:10 6->5:11 ", graph.toString());
    }

    /*
     * Testing Edge...
     */

    /**
     * Test whether the constructor method works when given different labels and weight.
     *
     * Testing strategy.
     *
     * Covers:  label is null, empty, Chinese characters.
     * weight is positive int and negative int.
     */
    @Test
    public void edgeTest() {
        Edge<String> nullEmptyPositive = new Edge<>(null, "", 1);
        Edge<String> nullChineseNegative = new Edge<>(null, "陈一帆", -1);

        //Source is null, target is empty, weight is positive.
        assertNull(nullEmptyPositive.getSource());
        assertEquals("", nullEmptyPositive.getTarget());
        assertEquals(1, nullEmptyPositive.getWeight());

        //Source is null, target is Chinese characters, weight is negative.
        assertNull(nullChineseNegative.getTarget());
        assertEquals("陈一帆", nullChineseNegative.getSource());
        assertEquals(1, nullChineseNegative.getWeight());
    }

    /**
     * Test whether the getter method for source works properly.
     *
     * Testing strategy.
     *
     * Partition the input source label as null, empty, Chinese characters.
     */
    @Test
    public void getSourceTest() {
        Edge<String> nullSource = new Edge<>(null, "", 1);
        Edge<String> emptySource = new Edge<>("", "陈一帆", 1);
        Edge<String> ChineseSource = new Edge<>("陈一帆", null, 1);

        assertNull(nullSource.getSource());
        assertEquals("", emptySource.getSource());
        assertEquals("陈一帆", ChineseSource.getSource());
    }

    /**
     * Test whether the getter method for target works properly.
     *
     * Testing strategy.
     *
     * Partition the input target label as null, empty, Chinese characters.
     */
    @Test
    public void getTargetTest() {
        Edge<String> nullTarget = new Edge<>("", null, 1);
        Edge<String> emptyTarget = new Edge<>(null, "", 1);
        Edge<String> ChineseTarget = new Edge<>(null, "陈一帆", 1);

        assertNull(nullTarget.getTarget());
        assertEquals("", emptyTarget.getTarget());
        assertEquals("陈一帆", ChineseTarget.getTarget());
    }

    /**
     * Test whether the getter method for weight works properly.
     *
     * Testing strategy.
     *
     * Partition the input weight as positive, negative.
     */
    @Test
    public void getWeightTest() {
        Edge<String> PositiveWeight = new Edge<>("", null, 1);
        Edge<String> NegativeWeight = new Edge<>(null, "陈一帆", -1);

        assertEquals(1, PositiveWeight.getWeight());
        assertEquals(1, NegativeWeight.getWeight());
    }

    /**
     * Test whether toString method works properly.
     *
     * Testing strategy
     *
     * Covers:
     * source label is null, empty or Chinese characters.
     * target label is null, empty or Chinese characters.
     * weight is positive or negative
     */
    @Test
    public void toStringTest() {
        Edge<String> nullEmptyPositive = new Edge<>(null, "", 1);
        Edge<String> nullEmptyNegative = new Edge<>(null, "", -1);
        Edge<String> emptyChinesePositive = new Edge<>("", "陈一帆", 1);
        Edge<String> emptyChineseNegative = new Edge<>("", "陈一帆", -1);
        Edge<String> ChineseNullPositive = new Edge<>("陈一帆", null, 1);
        Edge<String> ChineseNullNegative = new Edge<>("陈一帆", null, -1);

        assertEquals("null->:1",nullEmptyPositive.toString());
        assertEquals("->null:1",nullEmptyNegative.toString());
        assertEquals("->陈一帆:1",emptyChinesePositive.toString());
        assertEquals("陈一帆->:1",emptyChineseNegative.toString());
        assertEquals("陈一帆->null:1",ChineseNullPositive.toString());
        assertEquals("null->陈一帆:1",ChineseNullNegative.toString());
    }
}
