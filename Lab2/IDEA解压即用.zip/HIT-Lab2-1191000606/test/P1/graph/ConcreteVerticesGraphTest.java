/* Copyright (c) 2015-2016 MIT 6.005 course staff, all rights reserved.
 * Redistribution of original or derived work requires permission of course staff.
 */
package P1.graph;

import org.junit.Test;

import java.util.HashMap;

import static org.junit.Assert.*;

/**
 * Tests for ConcreteVerticesGraph.
 *
 * This class runs the GraphInstanceTest tests against ConcreteVerticesGraph, as
 * well as tests for that particular implementation.
 *
 * Tests against the Graph spec should be in GraphInstanceTest.
 */
public class ConcreteVerticesGraphTest extends GraphInstanceTest {

    /*
     * Provide a ConcreteVerticesGraph for tests in GraphInstanceTest.
     */
    @Override
    public Graph<String> emptyInstance() {
        return new ConcreteVerticesGraph<>();
    }

    /*
     * Testing ConcreteVerticesGraph...
     */

    /**
     * Test whether toString method works properly
     *
     * Testing strategy
     * Partition the graph `according to the num of Vertex and Edges.
     * Covers:  Vertices are none, few, many.
     * Edges are none, few, many.
     */
    @Test
    public void graphToStringTest() {
        Graph<String> graph = new ConcreteVerticesGraph<>();

        //Vertices and Edges are none.
        assertEquals("Graph: \n\tVertex: \n\tEdges: ",graph.toString());

        //Vertices are few and edges are none.
        graph.add("0");
        graph.add("1");
        assertEquals("Graph: \n\tVertex: 0 1 \n\tEdges: ",graph.toString());

        //Vertices are few and edges are few.
        graph.set("0", "1", -2);
        assertEquals("Graph: \n\tVertex: 0 1 \n\tEdges: 1->0:2 ",graph.toString());

        //Vertices are many and edges are few.
        graph.add("2");
        graph.add("3");
        graph.add("4");
        graph.add("5");
        graph.add("6");
        assertEquals("Graph: \n\tVertex: 0 1 2 3 4 5 6 \n\tEdges: 1->0:2 ",graph.toString());

        //Vertices are many and edges are many.
        graph.set("0","1",0);
        graph.set("0","3",0);
        graph.set("1","2",-3);
        graph.set("3","1",4);
        graph.set("4","1",-5);
        graph.set("4","2",6);
        graph.set("2","5",-7);
        graph.set("3","5",8);
        graph.set("6","3",-9);
        graph.set("6","4",10);
        graph.set("5","6",11);
        graph.set("5","6",-11);
        assertEquals("Graph: \n\tVertex: 0 1 2 3 4 5 6 \n\tEdges: 1->4:5 2->1:3 3->1:4 3->5:8 3->6:9 4->2:6 5->2:7 6->4:10 6->5:11 ",graph.toString());
    }


    /*
     * Testing Vertex...
     */

    /**
     * Test whether the constructor method works when given different labels.
     *
     * Testing strategy
     *
     * Partition the input labels as follows:
     * Covers:  name is null,
     * name is an empty String,
     * name is Chinese characters.
     */
    @Test
    public void VertexTest() {
        Vertex<String> nullPointer = new Vertex<>(null);
        Vertex<String> emptyString = new Vertex<>("");
        Vertex<String> ChineseCharacter = new Vertex<>("陈一帆");

        assertNull(nullPointer.getName());
        assertEquals("", emptyString.getName());
        assertEquals("陈一帆", ChineseCharacter.getName());
    }

    /**
     * Test whether the getter method for name works.
     *
     * Testing strategy
     * See whether name of vertex changes when the return name changed.
     */
    @Test
    public void getNameTest() {
        Vertex<String> nullPointer = new Vertex<>(null);
        Vertex<String> emptyString = new Vertex<>("");
        Vertex<String> ChineseCharacter = new Vertex<>("陈一帆");

        String nullString;
        String empty = emptyString.getName();
        String ChineseString = ChineseCharacter.getName();

        nullString = empty;
        empty = ChineseString;

        assertNotEquals(nullPointer.getName(), nullString);
        assertNotEquals(emptyString.getName(), empty);
        assertNotEquals(ChineseCharacter.getName(), null);
    }

    /**
     * Test whether the getter method for edgeMap works.
     *
     * Testing strategy
     * See whether edgeMap of vertex changes when the return edgeMap changed.
     */
    @Test
    public void getEdgeTest() {
        Vertex<String> nullPointer = new Vertex<>(null);
        Vertex<String> emptyString = new Vertex<>("");
        Vertex<String> ChineseCharacter = new Vertex<>("陈一帆");

        nullPointer.setEdgeMap(emptyString, -5);
        ChineseCharacter.setEdgeMap(nullPointer, 8);

        HashMap<Vertex<String>, Integer> nullEdgeMap = nullPointer.getEdgeMap();
        HashMap<Vertex<String>, Integer> emptyEdgeMap = emptyString.getEdgeMap();
        HashMap<Vertex<String>, Integer> ChineseEdgeMap = ChineseCharacter.getEdgeMap();

        nullEdgeMap.remove(emptyString);
        ChineseEdgeMap.put(nullPointer, 4);
        emptyEdgeMap.put(ChineseCharacter, -3);

        assertNotEquals(nullPointer.getEdgeMap(), nullEdgeMap);
        assertNotEquals(emptyString.getEdgeMap(), emptyEdgeMap);
        assertNotEquals(ChineseCharacter.getEdgeMap(), ChineseEdgeMap);
    }

    /**
     * test whether setter method for edgeMap can works properly
     *
     * Testing strategy
     *
     * Add and update method to edgeMap
     */
    @Test
    public void setEdgeMapTest() {
        Vertex<String> nullPointer = new Vertex<>(null);
        Vertex<String> emptyString = new Vertex<>("");
        Vertex<String> ChineseCharacter = new Vertex<>("陈一帆");

        HashMap<Vertex<String>, Integer> nullEdgeMap = nullPointer.getEdgeMap();
        HashMap<Vertex<String>, Integer> emptyEdgeMap = emptyString.getEdgeMap();
        HashMap<Vertex<String>, Integer> ChineseEdgeMap = ChineseCharacter.getEdgeMap();

        nullPointer.setEdgeMap(emptyString, -5);
        ChineseCharacter.setEdgeMap(nullPointer, 8);
        emptyString.setEdgeMap(nullPointer, 4);

        nullEdgeMap.put(emptyString, -4);
        nullEdgeMap.put(ChineseCharacter, -8);
        emptyEdgeMap.put(nullPointer, 4);
        ChineseEdgeMap.put(nullPointer, 8);

        assertEquals(nullEdgeMap, nullPointer.getEdgeMap());
        assertEquals(emptyEdgeMap, emptyString.getEdgeMap());
        assertEquals(ChineseEdgeMap, ChineseCharacter.getEdgeMap());
    }

    /**
     * Test whether toString method works properly.
     *
     * Testing strategy
     *
     * Choose three kinds of Vertex and test whether toString returns excepted Strings.
     */
    @Test
    public void vertexToStringTest() {
        Vertex<String> nullPointer = new Vertex<>(null);
        Vertex<String> emptyString = new Vertex<>("");
        Vertex<String> ChineseCharacter = new Vertex<>("陈一帆");

        nullPointer.setEdgeMap(emptyString, -5);
        ChineseCharacter.setEdgeMap(nullPointer, 8);
        emptyString.setEdgeMap(nullPointer, 4);
        emptyString.setEdgeMap(ChineseCharacter, 6);

        String nullString = "null\n\tinEdges: ->null:4 陈一帆->null:8 \n\toutEdges: ";
        String empty = "\n\tinEdges: \n\toutEdges: ->null:4 ->陈一帆:6 ";
        String ChineseString = "陈一帆\n\tinEdges: ->陈一帆:6 \n\toutEdges: 陈一帆->null:8 ";

        assertEquals(nullString, nullPointer.toString());
        assertEquals(empty, emptyString.toString());
        assertEquals(ChineseString, ChineseCharacter.toString());
    }
}
