package P2;

import P1.graph.Graph;
import org.junit.Assert;
import org.junit.Test;

import java.util.*;

public class FriendshipGraphTest {

    /**
     * Testing strategy
     *
     * Test some special kinds of input String.
     * Covers:  empty,  mixed of num and char,  Chinese characters
     */
    @Test
    public void addVertexTest() {
        FriendshipGraph friendshipGraph = new FriendshipGraph();
        Set<Person> personSet = new HashSet<>();

        Person emptyName = new Person("");
        personSet.add(emptyName);
        friendshipGraph.addVertex(emptyName);
        Assert.assertEquals(personSet, friendshipGraph.getGraph().vertices());

        Person mixedName = new Person("1191000606cyf");
        personSet.add(mixedName);
        friendshipGraph.addVertex(mixedName);
        Assert.assertEquals(personSet, friendshipGraph.getGraph().vertices());

        Person chineseName = new Person("陈一帆");
        personSet.add(chineseName);
        friendshipGraph.addVertex(chineseName);
        Assert.assertEquals(personSet, friendshipGraph.getGraph().vertices());
    }

    /**
     * Test if success add edge
     */
    @Test
    public void addEdgeTest() {
        FriendshipGraph friendshipGraph = new FriendshipGraph();
        Map<Person, Integer> sourceMap = new HashMap<>();
        Map<Person, Integer> targetMap = new HashMap<>();
        Person p = new Person("CYF");
        Person q = new Person("cyf");
        friendshipGraph.addVertex(p);
        friendshipGraph.addVertex(q);
        friendshipGraph.addEdge(p, q);
        sourceMap.put(p, 1);
        targetMap.put(q, 1);

        Assert.assertEquals(targetMap, friendshipGraph.getGraph().targets(p));
        Assert.assertEquals(sourceMap, friendshipGraph.getGraph().sources(q));
    }

    /**
     * Testing strategy
     *
     * Partition the graph according to the size of Vertex and Edges: none, a few, many
     * The size of Vertex: a few, many
     * The size of Edges: none, a few, many
     */
    @Test
    public void getDistanceTest() {
        FriendshipGraph friendshipGraph = new FriendshipGraph();

        Person p0 = new Person("0");
        Person p1 = new Person("1");
        Person p2 = new Person("2");
        Person p3 = new Person("3");
        Person p4 = new Person("4");
        Person p5 = new Person("5");
        Person p6 = new Person("6");

        friendshipGraph.addVertex(p0);
        friendshipGraph.addVertex(p1);

        //The graph with  a few vertex, and no edge
        Assert.assertEquals(0, friendshipGraph.getDistance(p0, p0));
        Assert.assertEquals(-1, friendshipGraph.getDistance(p0, p1));

        //The graph with many vertex, and no, a few, many edges
        friendshipGraph.addVertex(p2);
        friendshipGraph.addVertex(p3);
        friendshipGraph.addVertex(p4);
        friendshipGraph.addVertex(p5);
        friendshipGraph.addVertex(p6);

        //The graph with none edge
        Assert.assertEquals(0, friendshipGraph.getDistance(p0, p0));
        Assert.assertEquals(0, friendshipGraph.getDistance(p2, p2));
        Assert.assertEquals(0, friendshipGraph.getDistance(p4, p4));
        Assert.assertEquals(0, friendshipGraph.getDistance(p6, p6));

        Assert.assertEquals(-1, friendshipGraph.getDistance(p1, p2));
        Assert.assertEquals(-1, friendshipGraph.getDistance(p3, p4));
        Assert.assertEquals(-1, friendshipGraph.getDistance(p5, p6));
        Assert.assertEquals(-1, friendshipGraph.getDistance(p6, p0));

        //The graph with a few edges
        friendshipGraph.addEdge(p2, p1);
        friendshipGraph.addEdge(p1, p5);
        friendshipGraph.addEdge(p5, p4);
        friendshipGraph.addEdge(p4, p6);

        Assert.assertEquals(4, friendshipGraph.getDistance(p2, p6));
        Assert.assertEquals(2, friendshipGraph.getDistance(p5, p6));
        Assert.assertEquals(-1, friendshipGraph.getDistance(p0, p3));
        Assert.assertEquals(0, friendshipGraph.getDistance(p4, p4));

        //The graph with many edges
        friendshipGraph.addEdge(p0, p3);
        friendshipGraph.addEdge(p0, p6);
        friendshipGraph.addEdge(p1, p2);
        friendshipGraph.addEdge(p1, p3);
        friendshipGraph.addEdge(p1, p6);
        friendshipGraph.addEdge(p2, p4);
        friendshipGraph.addEdge(p3, p4);
        friendshipGraph.addEdge(p3, p5);
        friendshipGraph.addEdge(p4, p6);
        friendshipGraph.addEdge(p5, p6);
        friendshipGraph.addEdge(p6, p3);

        Assert.assertEquals(-1, friendshipGraph.getDistance(p0, p1));
        Assert.assertEquals(1, friendshipGraph.getDistance(p5, p6));
        Assert.assertEquals(3, friendshipGraph.getDistance(p2, p3));
        Assert.assertEquals(0, friendshipGraph.getDistance(p1, p1));
    }

    /**
     * Test whether getter method for Graph works.
     *
     * Testing strategy
     *
     * Change return graph and see whether graph in FriendshipGraph changes.
     */
    @Test
    public void getGraphTest() {
        FriendshipGraph friendshipGraph = new FriendshipGraph();
        Graph<Person> retGraph = friendshipGraph.getGraph();

        Person p0 = new Person("0");
        Person p1 = new Person("1");
        friendshipGraph.addVertex(p0);
        friendshipGraph.addVertex(p1);
        friendshipGraph.addEdge(p0,p1);

        Assert.assertNotEquals(friendshipGraph.getGraph(),retGraph);
    }
}
