package startup;

import interval.*;
import org.junit.Test;

import java.io.File;
import java.io.IOException;

import static org.junit.Assert.*;

public class APIsTest {
    /**
     * Testing Strategy: According to the given data
     *
     * @throws IntervalConflictException if conflict exists
     */
    @Test
    public void similarity() throws IntervalConflictException, IOException {
        APIs<String> API = new APIs<>(new File("./test/startup/txt/similarity.txt"));

        IntervalSet<String> a = new CommonIntervalSet<>(4);
        IntervalSet<String> b = new CommonIntervalSet<>(4);

        a.insert(new Period(0, 0), "happy");
        a.insert(new Period(2, 3), "happy");
        a.insert(new Period(1, 1), "sad");
        b.insert(new Period(1, 1), "sad");
        b.insert(new Period(2, 2), "meh");
        b.insert(new Period(3, 3), "happy");

        assertEquals(0.625, API.similarity(a, b), 0.001);
    }

    /**
     * Testing Strategy: None
     */
    @Test
    public void calConflictRatioTest() throws IntervalConflictException {
        IntervalSet<String> intervalSet=new OverlapIntervalSet<>(new CommonIntervalSet<>(5));

        intervalSet.insert(new Period(0,4),"CYF");
        intervalSet.insert(new Period(0,0),"1191000606");
        intervalSet.insert(new Period(0,0),"陈一帆");
        intervalSet.insert(new Period(2,3),"1191000606");

        assertEquals(0.6,APIs.calConflictRatio(intervalSet),0.001);
    }

    /**
     * Testing Strategy: None
     */
    @Test
    public void calFreeTimeTest() throws IntervalConflictException {
        IntervalSet<String> intervalSet=new CommonIntervalSet<>(5);

        intervalSet.insert(new Period(0,0),"1191000606");
        intervalSet.insert(new Period(2,3),"CYF");

        assertEquals(0.4,APIs.calcFreeTimeRadio(intervalSet),0.001);

    }
}
