package interval;

import org.junit.Test;

import static org.junit.Assert.*;

public class NoBlankIntervalSetTest extends IntervalSetDecoratorTest {
    @Override
    public IntervalSet<String> emptyInstance() {
        return new NoBlankIntervalSet<>(super.emptyInstance());
    }

    @Test
    public void toStringTest() throws IntervalConflictException {
        IntervalSet<String> intervalSet = emptyInstance();
        emptyInstance().insert(new Period(4, 4), "CYF");
        assertEquals("There is still empty interval",intervalSet.toString());
    }
}
