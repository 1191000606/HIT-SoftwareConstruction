package interval;

import java.util.HashSet;
import java.util.Set;

import static org.junit.Assert.assertEquals;

public class UniqueIntervalSetTest extends IntervalSetDecoratorTest {
    @Override
    public IntervalSet<String> emptyInstance() {
        return new UniqueIntervalSet<>(super.emptyInstance());
    }

    @Override
    public void insertTest() throws IntervalConflictException {
        IntervalSet<String> stringIntervalSet = emptyInstance();
        Set<String> stringSet = new HashSet<>();

        //empty
        stringSet.add(null);
        assertEquals(stringSet, stringIntervalSet.labels());

        //default
        stringIntervalSet.insert(new Period(0, 0), "CYF");
        stringSet.remove(null);
        stringSet.add("CYF");
        assertEquals(stringSet, stringIntervalSet.getLabel(0));

        //with blank
        stringIntervalSet.insert(new Period(2, 2), "1191000606");
        stringSet.remove("CYF");
        stringSet.add("1191000606");
        assertEquals(stringSet, stringIntervalSet.getLabel(2));
    }

}
