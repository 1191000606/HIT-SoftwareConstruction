package interval;

import org.junit.Test;

import static org.junit.Assert.*;

public class CommonIntervalSetTest extends IntervalSetTest {
    @Override
    public IntervalSet<String> emptyInstance() {
        return new CommonIntervalSet<>(5);
    }

    /**
     * Test whether toString() works. No Testing Strategy
     */
    @Test
    public void toStringTest() throws IntervalConflictException {
        IntervalSet<String> intervalSet = emptyInstance();
        intervalSet.insert(new Period(2, 2), "CYF");
        intervalSet.insert(new Period(4, 4), "1191000606");
        assertEquals("null\nnull\nCYF\nnull\n1191000606\n", intervalSet.toString());
    }
}
