package interval;

public abstract class IntervalSetDecoratorTest extends IntervalSetTest{
    @Override
    public IntervalSet<String> emptyInstance() {
        return new CommonIntervalSet<>(5);
    }
}
