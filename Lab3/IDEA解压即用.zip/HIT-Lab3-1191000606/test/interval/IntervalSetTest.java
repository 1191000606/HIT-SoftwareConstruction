package interval;

import org.junit.Test;

import java.util.*;

import static org.junit.Assert.*;

/**
 * Tests for instance methods of IntervalSet.
 *
 * <p>PS2 instructions: you MUST NOT add constructors, fields, or non-@Test
 * methods to this class, or change the spec of {@link #emptyInstance()}.
 * Your tests MUST only obtain IntervalSet instances by calling emptyInstance().
 * Your tests MUST NOT refer to specific concrete implementations.
 */
public abstract class IntervalSetTest {
    // Testing strategy
    //   Get IntervalSet object by using method emptyInstance, then test other methods in IntervalSet.interface

    /**
     * Overridden by implementation-specific test classes.
     *
     * @return a new empty IntervalSet of the particular implementation being tested
     */
    public abstract IntervalSet<String> emptyInstance();

    @Test(expected = AssertionError.class)
    public void testAssertionsEnabled() {
        assert false; // make sure assertions are enabled with VM argument: -ea
    }

    @Test
    public void testInitialLabelsEmpty() {
        Set<String> stringSet=emptyInstance().labels();
        stringSet.remove(null);
        assertEquals("expected new interval set to have no intervals",
                Collections.emptySet(),stringSet);
    }

    /**
     * Test whether insertTest works.
     *
     * Testing strategy
     * covers: empty, default , not unique, with blank
     *
     * @throws IntervalConflictException if exist conflict
     */
    @Test
    public void insertTest() throws IntervalConflictException {
        IntervalSet<String> stringIntervalSet = emptyInstance();
        Set<String> stringSet = new HashSet<>();

        //empty
        stringSet.add(null);
        assertEquals(stringSet, stringIntervalSet.labels());

        //default
        stringIntervalSet.insert(new Period(0, 0), "CYF");
        stringSet.remove(null);
        stringSet.add("CYF");
        assertEquals(stringSet, stringIntervalSet.getLabel(0));

        //with blank
        stringIntervalSet.insert(new Period(2, 2), "1191000606");
        stringSet.remove("CYF");
        stringSet.add("1191000606");
        assertEquals(stringSet, stringIntervalSet.getLabel(2));

        //not unique
        stringIntervalSet.insert(new Period(3, 4), "CYF");
        stringSet.remove("1191000606");
        stringSet.add("CYF");
        assertEquals(stringSet, stringIntervalSet.getLabel(3));
        assertEquals(stringSet, stringIntervalSet.getLabel(4));
    }

    /**
     * Test whether labels() works
     *
     * Testing strategy: None
     */
    @Test
    public void labelsTest() throws IntervalConflictException {
        IntervalSet<String> stringIntervalSet = emptyInstance();
        Set<String> stringSet = new HashSet<>();

        stringIntervalSet.insert(new Period(0, 2), "CYF");
        stringIntervalSet.insert(new Period(4, 4), "1191000606");
        stringSet.add("CYF");
        stringSet.add("1191000606");
        stringSet.add(null);
        assertEquals(stringSet, stringIntervalSet.labels());
    }

    /**
     * Test whether getLabels() works
     *
     * Testing strategy: partition the intervals as associated, no associated
     */
    @Test
    public void getLabelTest() throws IntervalConflictException {
        IntervalSet<String> stringIntervalSet = emptyInstance();
        Set<String> stringSet = new HashSet<>();

        //not associated
        stringSet.add(null);
        assertEquals(stringSet, stringIntervalSet.getLabel(0));

        //associated
        stringIntervalSet.insert(new Period(0, 2), "CYF");
        stringSet.remove(null);
        stringSet.add("CYF");
        assertEquals(stringSet, stringIntervalSet.getLabel(0));
    }

    /**
     * Test whether remove() works
     *
     * Testing strategy: partition the intervals as associated, no associated
     */
    @Test
    public void removeTest() throws IntervalConflictException {
        IntervalSet<String> stringIntervalSet = emptyInstance();
        Set<String> stringSet = new HashSet<>();

        //not associated
        assertFalse(stringIntervalSet.remove("CYF"));

        //associated
        stringIntervalSet.insert(new Period(0, 0), "CYF");
        assertTrue(stringIntervalSet.remove("CYF"));
        stringSet.add(null);
        assertEquals(stringSet, stringIntervalSet.labels());
        assertEquals(stringSet, stringIntervalSet.getLabel(0));
    }

    /**
     * Test whether getBlank() works
     *
     * Testing strategy: partition according to the num of Blank: the whole interval, few, many, none
     */
    @Test
    public void getBlankTest() throws IntervalConflictException {
        IntervalSet<String> stringIntervalSet = emptyInstance();
        List<Period> periods = new ArrayList<>();

        //the whole interval
        periods.add(new Period(0, 4));
        assertEquals(periods, stringIntervalSet.getBlank());

        //many blanks
        stringIntervalSet.insert(new Period(1, 1), "CYF");
        stringIntervalSet.insert(new Period(3, 3), "1191000606");
        periods.remove(0);
        periods.add(new Period(0, 0));
        periods.add(new Period(2, 2));
        periods.add(new Period(4, 4));
        assertEquals(periods,stringIntervalSet.getBlank());

        //few blank
        stringIntervalSet.insert(new Period(0,0),"cyf");
        stringIntervalSet.insert(new Period(4,4),"陈一帆");
        periods.remove(0);
        periods.remove(1);
        assertEquals(periods,stringIntervalSet.getBlank());

        //none
        stringIntervalSet.insert(new Period(2,2),"1903003");
        periods.remove(0);
        assertEquals(periods,stringIntervalSet.getBlank());
    }

    /**
     * Test whether size() works. No Testing strategy
     */
    @Test
    public void size() {
        assertEquals(5,emptyInstance().size());
    }

}
