package interval;

import org.junit.Test;

import java.util.HashSet;
import java.util.Set;

import static org.junit.Assert.*;

public class OverlapIntervalSetTest extends IntervalSetDecoratorTest {
    @Override
    public IntervalSet<String> emptyInstance() {
        return new OverlapIntervalSet<>(super.emptyInstance());
    }

    @Override
    public void insertTest() throws IntervalConflictException {
        IntervalSet<String> intervalSet = emptyInstance();
        Set<String> stringSet = new HashSet<>();

        intervalSet.insert(new Period(0, 2), "CYF");
        intervalSet.insert(new Period(1, 1), "1191000606");
        intervalSet.insert(new Period(1, 3), "陈一帆");

        stringSet.add("CYF");
        stringSet.add("1191000606");
        stringSet.add("陈一帆");

        assertEquals(stringSet, intervalSet.getLabel(1));
    }

    @Override
    public void labelsTest() throws IntervalConflictException {
        IntervalSet<String> intervalSet = emptyInstance();
        Set<String> stringSet = new HashSet<>();

        intervalSet.insert(new Period(0, 2), "CYF");
        intervalSet.insert(new Period(1, 1), "1191000606");
        intervalSet.insert(new Period(1, 3), "陈一帆");

        stringSet.add("CYF");
        stringSet.add("1191000606");
        stringSet.add("陈一帆");
        stringSet.add(null);

        assertEquals(stringSet, intervalSet.labels());
    }

    @Override
    public void getLabelTest() throws IntervalConflictException {
        IntervalSet<String> intervalSet = emptyInstance();
        Set<String> stringSet = new HashSet<>();

        intervalSet.insert(new Period(0, 2), "CYF");
        intervalSet.insert(new Period(1, 1), "1191000606");
        intervalSet.insert(new Period(1, 3), "陈一帆");

        stringSet.add("CYF");
        stringSet.add("1191000606");
        stringSet.add("陈一帆");

        assertEquals(stringSet, intervalSet.getLabel(1));
    }

    @Override
    public void removeTest() throws IntervalConflictException {
        IntervalSet<String> intervalSet = emptyInstance();
        Set<String> stringSet = new HashSet<>();

        intervalSet.insert(new Period(0, 4), "CYF");
        intervalSet.insert(new Period(1, 2), "1191000606");
        intervalSet.insert(new Period(4, 4), "1191000606");
        intervalSet.remove("1191000606");
        stringSet.add("CYF");

        assertEquals(stringSet,intervalSet.labels());
    }

    @Test
    public void toStringTest() throws IntervalConflictException {
        IntervalSet<String> intervalSet = emptyInstance();

        intervalSet.insert(new Period(1, 4), "CYF");
        intervalSet.insert(new Period(1, 2), "1191000606");
        intervalSet.insert(new Period(4, 4), "陈一帆");

        assertEquals("null\nCYF\t1191000606\nCYF\t1191000606\nCYF\nCYF\t陈一帆\n",intervalSet.toString());
    }

}
