package interval;

import java.util.*;

//A decorator of CommonInterval. A interval can be associated two or more labels
public class OverlapIntervalSet<L> extends IntervalSetDecorator<L> {
    private final Map<Integer, Set<L>> additionalLabelSet = new HashMap<>();

    public OverlapIntervalSet(IntervalSet<L> intervalList) {
        super(intervalList);
    }

    @Override
    public void insert(Period period, L label) throws IntervalConflictException {
        try {
            intervalList.insert(period, label);
        } catch (IntervalOverlapException overlapException) {
            Set<Integer> keySet = additionalLabelSet.keySet();

            for (int i = Integer.parseInt(overlapException.getMessage()); i <= period.getEnd(); i++) {
                Object interval = intervalList.getLabel(i);

                if (interval == null) {
                    try {
                        intervalList.insert(new Period(i, i), label);
                    } catch (IntervalOverlapException e) {
                        assert false;
                    }
                } else if (!label.equals(interval)) {
                    Set<L> labelSet;
                    if (keySet.contains(i)) {
                        labelSet = additionalLabelSet.get(i);
                    } else {
                        labelSet = new HashSet<>();
                    }
                    labelSet.add(label);
                    additionalLabelSet.put(i, labelSet);
                }
            }
        }
    }

    @Override
    public Set<L> labels() {
        Set<L> retLabelSet = intervalList.labels();

        for (Set<L> value : additionalLabelSet.values()) {
            retLabelSet.addAll(value);
        }

        return retLabelSet;
    }

    @Override
    public Set<L> getLabel(int index) {
        Set<L> labelSet = intervalList.getLabel(index);
        if (additionalLabelSet.containsKey(index)) {
            labelSet.addAll(additionalLabelSet.get(index));

        }
        return labelSet;
    }

    @Override
    public boolean remove(L label) {
        boolean isFound = intervalList.remove(label);

        for (Map.Entry<Integer, Set<L>> entry : additionalLabelSet.entrySet()) {
            if (entry.getValue().remove(label)) {
                isFound = true;
                additionalLabelSet.put(entry.getKey(), entry.getValue());
            }
        }

        return isFound;
    }

    @Override
    public String toString() {
        String intervalListString = intervalList.toString();
        String[] intervalStrings = intervalListString.split("\n");
        StringBuilder retString = new StringBuilder();
        Set<Integer> keySet = additionalLabelSet.keySet();

        for (int i = 0; i < intervalStrings.length; i++) {
            retString.append(intervalStrings[i]);

            if (keySet.contains(i)) {
                for (L label : additionalLabelSet.get(i)) {
                    retString.append("\t");
                    retString.append(label.toString());
                }
            }

            retString.append("\n");
        }

        return retString.toString();
    }

}
