package interval;

public class IntervalOverlapException extends IntervalConflictException{
    /**
     * Make a new interval conflict exception with the given detail message
     *
     * @param message the detail message
     */
    public IntervalOverlapException(String message) {
        super(message);
    }
}
