package interval;

public class IntervalRepeatException extends IntervalConflictException{
    /**
     * Make a new interval conflict exception with the given detail message
     *
     * @param message the detail message
     */
    public IntervalRepeatException(String message) {
        super(message);
    }
}
