package interval;

import java.util.List;
import java.util.Set;

public abstract class IntervalSetDecorator<L> implements IntervalSet<L> {
    protected final IntervalSet<L> intervalList;

    protected IntervalSetDecorator(IntervalSet<L> intervalList) {
        this.intervalList = intervalList;
    }

    public void insert(Period period, L label) throws IntervalConflictException {
        intervalList.insert(period, label);
    }

    public Set<L> labels() {
        return intervalList.labels();
    }

    public Set<L> getLabel(int index) {
        return intervalList.getLabel(index);
    }

    public boolean remove(L label) {
        return intervalList.remove(label);
    }

    public List<Period> getBlank() {
        return intervalList.getBlank();
    }

    public int size() {
        return intervalList.size();
    }

    public String toString() {
        return intervalList.toString();
    }
}
