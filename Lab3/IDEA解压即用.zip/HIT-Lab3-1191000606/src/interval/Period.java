package interval;

// An immutable ADT which represent a time period without any label.
public class Period {
    private final int start;
    private final int end;

    //AF: start and end represent a time period [start,end].
    //RI: end should be greater than start. And Both should be non-negative.
    //safe from exposure: All field is private and final. No setter method provided.

    public Period(int start, int end) {
        this.start = start;
        this.end = end;
    }

    public int getStart() {
        return start;
    }

    public int getEnd() {
        return end;
    }

    @Override
    public int hashCode() {
        return start;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Period period = (Period) o;

        return start == period.start && end == period.end;
    }
}
