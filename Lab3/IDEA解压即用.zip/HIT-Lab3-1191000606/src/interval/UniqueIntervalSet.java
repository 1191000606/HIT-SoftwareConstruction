package interval;

//A decorator of CommonInterval. The label of intervals should be unique.
public class UniqueIntervalSet<L> extends IntervalSetDecorator<L> {
    public UniqueIntervalSet(IntervalSet<L> intervalList) {
        super(intervalList);
    }

    @Override
    public void insert(Period period,L label) throws IntervalConflictException {
        if (!intervalList.labels().contains(label)) {
            intervalList.insert(period, label);
        } else {
            throw new IntervalRepeatException(label+" has been associated with intervals.");
        }
    }
}
