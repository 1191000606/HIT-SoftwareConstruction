package interval;

import java.util.*;

/**
 * An implementation of IntervalSet.
 *
 * A mutable set of labeled intervals, where each label is associated with a closed period [start,end].
 *
 * On this ADT:
 * Label don't need to be unique.
 * Intervals are no-overlapping, which means a time unit couldn't have two or more labels.
 * It's permitted that some period don't have label.
 * It couldn't be looped.
 *
 * But these four rules can be changed with corresponding decorators
 * UniqueIntervalSet
 * OverlapIntervalSet
 * NoBlankIntervalSet
 * LoopIntervalSet
 *
 * @param <L> type of labels in this set, must be immutable
 */
public class CommonIntervalSet<L> implements IntervalSet<L> {
    private final List<L> intervalList = new ArrayList<>();

    public CommonIntervalSet(int size) {
        for (int i = 0; i < size; i++) {
            intervalList.add(null);
        }
    }

    //AF:   intervalList represents intervals. L is label of the interval.
    //RI:   two separated intervals couldn't be associated with same label.
    //Safe from exposure: intervalList is private and no getter method provided.

    public void insert(Period period, L label) throws IntervalOverlapException {
        for (int i = period.getStart(); i <= period.getEnd(); i++) {
            L l = intervalList.get(i);
            if (l != null && !l.equals(label)) {
                throw new IntervalOverlapException(String.valueOf(i));
            }
        }

        for (int i = period.getStart(); i <= period.getEnd(); i++) {
            intervalList.set(i, label);
        }
    }

    public Set<L> labels() {
        return new HashSet<>(intervalList);
    }

    public Set<L> getLabel(int index) {
        Set<L> retSet = new HashSet<>();
        retSet.add(intervalList.get(index));
        return retSet;
    }

    public boolean remove(L label) {
        if (!intervalList.contains(label)) {
            return false;
        }

        for (int i = intervalList.indexOf(label); i <= intervalList.lastIndexOf(label); i++) {
            if (label.equals(intervalList.get(i))) {
                intervalList.set(i, null);
            }
        }

        return true;
    }

    public List<Period> getBlank() {
        List<Period> periodList = new ArrayList<>();
        int start, end = 0;
        int index = 0;
        int size = intervalList.size();

        do {
            if (intervalList.get(index) != null) {
                index++;
            } else {
                start = index;
                end = index;
                while (end + 1 < size && intervalList.get(end + 1) == null) {
                    end++;
                }
                periodList.add(new Period(start, end));
                index = end + 1;
            }
        } while (index != size && end != size);

        return periodList;
    }

    public int size() {
        return intervalList.size();
    }

    @Override
    public String toString() {
        StringBuilder retString = new StringBuilder();
        for (L interval : intervalList) {
            retString.append(interval).append("\n");
        }

        return retString.toString();
    }
}
