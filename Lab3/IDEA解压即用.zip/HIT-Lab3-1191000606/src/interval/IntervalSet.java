package interval;

import java.util.List;
import java.util.Set;

/**
 * A mutable set of labeled intervals, where label is associated with half-open interval [start,end).
 *
 * Labels are of immutable type L and must implement the Object contract:
 * they are compared for equality using Object.equals(java.lang.Object).
 *
 * @param <L> type of labels in this set, must be immutable
 */

public interface IntervalSet<L> {

    /**
     * Create an empty interval set.
     *
     * @param <L> type of labels of the interval set, must be immutable
     * @return a new empty interval set
     */
    static <L> IntervalSet<L> empty() {
        return new CommonIntervalSet<>(0);
    }

    /**
     * Add a labeled interval (if not present) to this set, if it does not conflict
     * with existing intervals.
     *
     * Labeled intervals conflict according to client's need.
     *
     * @param period low end of the interval, inclusive
     * @param label  label to add
     * @throws IntervalConflictException according to client's need.
     */
    void insert(Period period, L label) throws IntervalConflictException;

    /**
     * Get the labels in this set.
     *
     * @return the labels in this set
     */
    Set<L> labels();

    /**
     * get the label of one interval
     *
     * @param index the index of interval in interval
     * @return the label of index
     */
    Set<L> getLabel(int index);

    /**
     * Remove a labeled interval from this set, if present.
     *
     * @param label to remove
     * @return true if this set contained label, and false otherwise
     */
    boolean remove(L label);

    /**
     * get blank periods whenever
     *
     * @return the list of blank periods
     */
    List<Period> getBlank();

    /**
     * get size of intervalList
     *
     * @return the size of intervalList
     */
    int size();
}
