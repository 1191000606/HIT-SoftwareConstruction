package interval;

//A decorator of CommonInterval. All intervals will not be blank.
public class NoBlankIntervalSet<L> extends IntervalSetDecorator<L> {
    public NoBlankIntervalSet(IntervalSet<L> intervalList) {
        super(intervalList);
    }

    @Override
    public String toString() {
        if (intervalList.labels().contains(null)) {
            return "There is still empty interval";
        }

        return intervalList.toString();
    }

}
