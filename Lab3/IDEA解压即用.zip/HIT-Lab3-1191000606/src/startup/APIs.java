package startup;

import interval.IntervalSet;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * A mutable measure of similarity between multi-interval sets of
 * Strings.
 *
 * An instance of Similarity uses a client-provided definition of label
 * similarities.txt, where 0 is least similar and 1 is most similar.
 *
 * Given two multi-interval sets, let min be the minimum start of any of their
 * intervals, and let max be the maximum end. The similarity between the two
 * sets is the ratio:
 * (sum of piecewise-matching between the sets) / (max - min)
 *
 * The amount of piecewise-matching for any unit interval [i, i+1) is:
 * 0 if neither set has a label on that interval
 * 0 if only one set has a label on that interval
 * otherwise, the similarity between the labels as defined for this Similarity instance
 *
 * For example, suppose you have multi-interval sets that use labels "happy", "sad", and "meh";
 * and similarity between labels is defined as:
 *
 * 1 if both are "happy", both "sad", or both "meh"
 * 0.5 if one is "meh" and the other is "happy" or "sad"
 * 0 otherwise
 *
 * Then the similarity between these two sets:
 * { "happy" = [[0, 1), [2,4)], "sad" = [[1,2)] }
 * { "sad" = [[1, 2)], "meh" = [[2,3)], "happy" = [[3,4)] }
 *
 * would be: (0 + 1 + 0.5 + 1) / (4 - 0) = 0.625
 *
 * PS2 instructions: this is a required ADT class, and you MUST NOT weaken the
 * required specifications. However you MAY strengthen the specifications and
 * you MAY add additional methods.
 */

public class APIs<L> {
    private final Map<String, Double> similarityMap = new HashMap<>();

    /**
     * Create a new Similarity where similarity between labels is defined in the given file.
     * Each line of similarities.txt must contain exactly three pieces, separated by one or more spaces.
     * The first two pieces give a pair of strings, and the third piece gives the decimal similarity
     * between them, in a format allowed by Double.valueOf(String), between 0 and 1 inclusive.
     *
     * Similarity between labels is symmetric, so the order of strings in the pair is irrelevant.
     * A pair may not appear more than once. The similarity between all other pairs of strings is 0.
     * This format cannot define non-zero similarity for strings that contain newlines or spaces,
     * or for the empty string.
     *
     * For example, the following file defines the similarity function used in the example at the top of this class:
     *
     * happy happy 1
     * sad   sad   1
     * meh   meh   1
     * meh   happy 0.5
     * meh   sad   0.5
     *
     * @param similarities label similarity definition as described above
     * @throws IOException if the similarity file cannot be found or read
     */
    public APIs(File similarities) throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader(similarities));
        String line;
        String[] words;
        while ((line = reader.readLine()) != null) {
            words = line.replaceAll(" +"," ").split(" ");
            similarityMap.put(words[0] + words[1], Double.parseDouble(words[2]));
            if(!words[0].equals(words[1])){
                similarityMap.put(words[1] + words[0], Double.parseDouble(words[2]));
            }
        }
    }

    /**
     * Compute similarity between two multi-interval sets. Returns a value between 0 and 1 inclusive.
     *
     * @param a non-empty multi-interval set of strings
     * @param b non-empty multi-interval set of strings
     * @return similarity between a and b as defined above
     */
    public double similarity(IntervalSet<String> a, IntervalSet<String> b) {
        int minLength = Integer.min(a.size(), b.size());
        int maxLength = Integer.max(a.size(), b.size());
        double similaritySum = 0;

        for (int i = 0; i < minLength; i++) {
            Set<String> aSet = a.getLabel(i);
            Set<String> bSet = b.getLabel(i);

            if (aSet.contains(null) || bSet.contains(null)) {
                continue;
            }

            if (aSet.size() > 1 || bSet.size() > 1) {
                System.out.println("不能有重叠的情况");
                System.exit(1);
            }

            String str = aSet.toArray(new String[0])[0] + bSet.toArray(new String[0])[0];

            similaritySum += similarityMap.getOrDefault(str, 0.0);
        }

        return similaritySum / maxLength;
    }

    /**
     * calculate the ratio of conflicted intervals.
     * @param set the given IntervalSet
     * @return the radio.
     */
    public static double calConflictRatio(IntervalSet<?> set) {
        int length=set.size();
        int conflictNum=0;

        for(int i=0;i<length;i++)
        {
            if(set.getLabel(i).size()>=2)
            {
                conflictNum++;
            }
        }

        return (double) conflictNum/length;
    }

    /**
     * calculate the ratio of free intervals.
     * @param set the given IntervalSet
     * @return the radio.
     */
    public static double calcFreeTimeRadio(IntervalSet<?> set) {
        int length=set.size();
        int freeNum=0;

        for(int i=0;i<length;i++)
        {
            if(set.getLabel(i).contains(null))
            {
                freeNum++;
            }
        }

        return (double) freeNum/length;
    }
}
