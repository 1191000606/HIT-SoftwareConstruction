package ProcessSchedule;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

import static java.lang.Thread.sleep;

public class ProcessScheduleApp {
    private static final Map<Process, Integer> processMap = new HashMap<>();

    private static void initial(String filename) throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader("./src/ProcessSchedule/txt/" + filename));

        String line;
        while ((line = reader.readLine()) != null) {
            String[] words = line.split(" ");
            processMap.put(new Process(words[0], words[1], Integer.parseInt(words[2]), Integer.parseInt(words[3])), 0);
        }
    }

    private static void Perform(PerformStrategy performMethod) throws InterruptedException {
        performMethod.Perform(processMap);
    }

    public static void main(String[] args) throws IOException, InterruptedException {
        System.out.println("————————————————————————Welcome To CYF OS—————————————————————————");

        System.out.print("请输入进程文件名：");
        String filename = new Scanner(System.in).nextLine();
        initial(filename);

        System.out.print("输入0以随机策略运行，输入1以最短进程优先策略开始运行：");
        int mode = new Scanner(System.in).nextInt();

        if (mode == 0) {
            Perform(new RandomPerformStrategy());
        } else if (mode == 1) {
            Perform(new OrderPerformStrategy());
        }
    }
}
