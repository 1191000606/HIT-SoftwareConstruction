package ProcessSchedule;

//An immutable ADT represent process.
public class Process {
    private final String pid;
    private final String name;
    private final int minTime;
    private final int maxTime;

    //AF: pid,name,minTime,maxTime represent all necessary information of process.
    //RI: All String fields should not be null. All int field should be positive. And maxTime should greater than minTime.
    //safe from exposure: All fields are private and final. No setter method provided.

    public Process(String pid, String name, int minTime, int maxTime) {
        this.pid = pid;
        this.name = name;
        this.minTime = minTime;
        this.maxTime = maxTime;
    }

    public String getPid() {
        return pid;
    }

    public String getName() {
        return name;
    }

    public int getMinTime() {
        return minTime;
    }

    public int getMaxTime() {
        return maxTime;
    }

    @Override
    public int hashCode() {
        return minTime;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }

        if (!(obj instanceof Process)) {
            return false;
        }

        Process process = (Process) obj;

        return pid.equals(process.getPid()) && name.equals(process.getName()) && minTime == process.getMinTime() && maxTime == process.getMaxTime();
    }

    @Override
    public String toString() {
        return pid + ' ' + name;
    }
}
