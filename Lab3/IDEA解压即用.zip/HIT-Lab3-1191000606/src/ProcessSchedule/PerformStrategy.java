package ProcessSchedule;

import java.util.Map;

public interface PerformStrategy {
    void Perform(Map<Process, Integer> processMap) throws InterruptedException;
}
