package ProcessSchedule;

import java.util.*;

import static java.lang.Thread.sleep;

public class OrderPerformStrategy implements PerformStrategy{
    public void Perform(Map<Process, Integer> processMap) throws InterruptedException {
        System.out.print("是否要使用随机的方法初始化进程已执行时间：（1/0）");

        if (Integer.parseInt(new Scanner(System.in).nextLine()) == 1) {
            Random r = new Random();
            for (Process p : processMap.keySet()) {
                double radio = r.nextDouble();
                processMap.put(p, (int) (p.getMinTime() * radio));
            }
        } else {
            processMap.replaceAll((p, v) -> 0);
        }

        for (Map.Entry<Process, Integer> entry : processMap.entrySet()) {
            int rest = entry.getKey().getMinTime() - entry.getValue();
            System.out.println(entry.getKey() + " 已执行 " + entry.getValue() + " 剩余 " + rest);
            processMap.put(entry.getKey(), rest);
        }

        List<Map.Entry<Process, Integer>> entryList = new ArrayList<>(processMap.entrySet());
        entryList.sort(Map.Entry.comparingByValue());

        System.out.println("****************************Performing*****************************");
        sleep(3000);

        for (Map.Entry<Process, Integer> entry : entryList) {
            sleep(entry.getValue());
            System.out.println(entry.getKey() + " 执行完毕");
        }
    }
}
