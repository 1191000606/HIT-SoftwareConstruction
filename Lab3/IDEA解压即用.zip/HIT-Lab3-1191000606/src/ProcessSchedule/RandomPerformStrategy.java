package ProcessSchedule;

import java.util.Map;
import java.util.Random;

import static java.lang.Thread.sleep;

public class RandomPerformStrategy implements PerformStrategy {
    public void Perform(Map<ProcessSchedule.Process, Integer> processMap) throws InterruptedException {
        Random r = new Random();
        Process[] processArray = processMap.keySet().toArray(new Process[0]);
        int size = processArray.length;

        System.out.println("****************************Performing*****************************");

        while (processMap.size() != 0) {
            double radio = r.nextDouble();
            int index = r.nextInt(size);
            Process p = processArray[index];
            while (!processMap.containsKey(p)) {
                p = processArray[(++index) % size];
            }

            int pTime = (int) (p.getMaxTime() * radio);
            int pSum = processMap.get(p);

            sleep(pTime);
            System.out.println("执行：" + p + "\t" + pTime + "时间片");

            if (pTime + pSum > p.getMinTime()) {
                System.out.println(p + "执行完毕");
                processMap.remove(p);
            } else {
                processMap.put(p, pTime + pSum);
            }

            sleep((index % 5 + 5) * 100);
        }
    }
}
