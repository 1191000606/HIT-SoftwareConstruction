package CourseSchedule;

import interval.*;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDate;
import java.util.*;

import static java.time.temporal.ChronoUnit.DAYS;

public class CourseScheduleApp {
    private static final int maxCourseOfWeek = 35;
    private static final List<Course> courseList = new ArrayList<>();
    private static final IntervalSet<Course> intervalSet = new OverlapIntervalSet<>(new CommonIntervalSet<>(maxCourseOfWeek));
    private static int[] hoursAssigned;
    private static LocalDate start;
    private static int weekNum;


    private static void initial(String filename) throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader("./src/CourseSchedule/txt/" + filename));

        String line = reader.readLine();
        start = LocalDate.parse(line.split(" ")[0]);
        weekNum = Integer.parseInt(line.split(" ")[1]);

        while ((line = reader.readLine()) != null) {
            String[] words = line.split(" ");
            courseList.add(new Course(words[0], words[1], words[2], words[3], Integer.parseInt(words[4])));
        }

        hoursAssigned = new int[courseList.size()];
        Arrays.fill(hoursAssigned, 0);
    }

    private static void display() {
        System.out.println("课程信息如下：（已编号）");
        System.out.println("\t课程名称\t授课老师\t教室\t每周学时");

        int index = 0;
        for (Course course : courseList) {
            System.out.println(String.valueOf(index) + '\t' + course.getName() + '\t' + course.getTeacher() + '\t' + course.getClassroom() + '\t' + course.getWeekNum());
            index++;
        }
    }

    private static void manualSchedule() throws IntervalConflictException {
        System.out.println("请输入课程编号（非课程代码，以上述输出为准），排课在周几，第几节（奇数开头，一次只能输入相邻的两节课）。例：0 1 5 6表示安排编号为0的课在周一5-6节");
        String[] str = new Scanner(System.in).nextLine().split(" ");
        int indexOfCourse = Integer.parseInt(str[0]);
        int index = (Integer.parseInt(str[1]) - 1) * 5 + Integer.parseInt(str[3]) / 2-1;
        Course course = courseList.get(indexOfCourse);

        if (hoursAssigned[indexOfCourse] == course.getWeekNum()) {
            System.out.println("排课失败，本周该课课时已满");
            return;
        }

        for (Course interval : intervalSet.getLabel(index)) {
            if (interval == null) {
                break;
            }
            if (interval.getTeacher().equals(course.getTeacher())) {
                System.out.println("排课失败，老师冲突");
                return;
            } else if (interval.getClassroom().equals(course.getClassroom())) {
                System.out.println("排课失败，教室冲突");
                return;
            }
        }

        intervalSet.insert(new Period(index, index), course);
        hoursAssigned[indexOfCourse] += 2;
    }

    private static void view() {
        System.out.println("编号\t剩余课程\t老师\t剩余学时");
        for (int i = 0; i < hoursAssigned.length; i++) {
            if (hoursAssigned[i] != courseList.get(i).getWeekNum()) {
                System.out.println(i+"\t"+courseList.get(i) + "\t" + (courseList.get(i).getWeekNum() - hoursAssigned[i]));
            }
        }

        int blankNum = 0;
        int repeatNum = 0;

        for (int i = 0; i < maxCourseOfWeek; i++) {
            Set<Course> intervals = intervalSet.getLabel(i);
            if (intervals.contains(null)) {
                blankNum++;
            } else if (intervals.size() >= 2) {
                repeatNum++;
            }
        }

        System.out.println("空闲时间占比" + (double) blankNum / maxCourseOfWeek + "\t重复时间占比" + (double) repeatNum / maxCourseOfWeek);
    }

    private static void find() {
        System.out.print("请输入日期：（要求YYYY-MM-YY形式）");
        LocalDate date = LocalDate.parse(new Scanner(System.in).nextLine());

        int length = (int) DAYS.between(start, date);

        if (length > weekNum * 7) {
            System.out.println("该日期不在本学期");
        }

        show(length % 7 + 1);
    }

    private static void export() {
        String dayOfWeek = "周一二三四五六日";
        for (int i = 1; i <= 7; i++) {
            System.out.println("周" + dayOfWeek.charAt(i));
            show(i);
        }
    }

    //notices: 1 represent Monday
    private static void show(int dayOfWeek) {
        for (int i = 0; i < 5; i++) {
            Set<Course> intervals = intervalSet.getLabel((dayOfWeek - 1) * 5 + i);
            if (intervals.contains(null)) {
                continue;
            }
            System.out.print((i * 2 + 1) + "-" + (i * 2 + 2) + "节: ");

            for (Course interval : intervals) {
                System.out.print(interval.getName() + ' ' + interval.getTeacher() + ' ' + interval.getClassroom() + '\t');
            }

            System.out.print('\n');
        }
    }


    public static void main(String[] args) throws IOException, IntervalConflictException {
        System.out.println("—————————————————————欢迎使用CourseSchedule排课系统—————————————————————");
        System.out.print("请输入课程文件名：");
        String filename = new Scanner(System.in).nextLine();

        initial(filename);
        display();

        System.out.println("****************************现在开始排课********************************");
        System.out.println("共有5个功能：1 手动排课  2 查看排课情况  3 打印课表  4 查询课表  5 退出");

        int mode;

        while (true) {
            System.out.print("请选择功能：（输入对应数字即可）");
            mode = new Scanner(System.in).nextInt();
            switch (mode) {
                case 1:
                    manualSchedule();
                    break;
                case 2:
                    view();
                    break;
                case 3:
                    export();
                    break;
                case 4:
                    find();
                    break;
                case 5:
                    System.out.println("已成功退出");
                    System.exit(0);
            }
        }
    }
}
