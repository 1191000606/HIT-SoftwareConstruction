package CourseSchedule;

//An immutable ADT represent course.
public class Course {
    private final String ID;
    private final String name;
    private final String teacher;
    private final String classroom;
    private final int hoursPerWeek;

    //AF: ID,name,teacher,classroom,hoursPerWeek represent all necessary information of process. hoursPerWeek is the hours of the course one week.
    //RI: All String fields should not be null. hoursPerWeek should be positive even.
    //safe from exposure: All fields are private and final. No setter method provided.

    Course(String ID, String name, String teacher, String classroom, int weekNum) {
        this.ID = ID;
        this.name = name;
        this.teacher = teacher;
        this.classroom = classroom;
        this.hoursPerWeek = weekNum;
    }

    public String getID() {
        return ID;
    }

    public String getName() {
        return name;
    }

    public String getTeacher() {
        return teacher;
    }

    public String getClassroom() {
        return classroom;
    }

    public int getWeekNum() {
        return hoursPerWeek;
    }

    @Override
    public int hashCode() {
        return hoursPerWeek + ID.hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }

        if (!(obj instanceof Course)) {
            return false;
        }

        Course course = (Course) obj;
        return ID.equals(course.getID()) && name.equals(course.getName()) && teacher.equals(course.getTeacher()) && classroom.equals(course.getClassroom()) && hoursPerWeek == course.getWeekNum();
    }

    @Override
    public String toString() {
        return name + "\t" + teacher;
    }
}
