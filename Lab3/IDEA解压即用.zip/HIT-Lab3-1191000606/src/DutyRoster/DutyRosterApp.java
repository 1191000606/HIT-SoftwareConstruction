package DutyRoster;

import interval.*;

import java.io.*;
import java.time.LocalDate;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static java.time.temporal.ChronoUnit.DAYS;


public class DutyRosterApp {
    private final static List<Employee> employees = new ArrayList<>();
    private static LocalDate start;
    private static LocalDate end;
    private static int length;
    private static IntervalSet<Employee> intervalSet;
    private static String lines;

    private static void initial(String filename) throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader("./src/DutyRoster/txt/" + filename));
        StringBuilder linesBuilder = new StringBuilder();
        String str;
        while ((str = reader.readLine()) != null) {
            linesBuilder.append(str);
        }
        lines = linesBuilder.toString();

        String employeePattern = "([A-Za-z0-9]+)\\{([A-Za-z ]+),([0-9-]{13})(})";
        Pattern employeeR = Pattern.compile(employeePattern);
        Matcher employeeM = employeeR.matcher(lines);

        while (employeeM.find()) {
            String phoneNumber = employeeM.group(3);
            String[] phoneNumberParts = phoneNumber.split("-");
            if (phoneNumberParts[0].length() != 3 || phoneNumberParts[1].length() != 4 || phoneNumberParts[2].length() != 4) {
                System.out.println(phoneNumber + "为不合法联系方式");
                System.exit(1);
            }
            phoneNumber = phoneNumberParts[0] + phoneNumberParts[1] + phoneNumberParts[2];

            Employee e = new Employee(employeeM.group(1), employeeM.group(2), phoneNumber);
            if (!employees.contains(e)) {
                employees.add(e);
            } else {
                break;
            }
        }

        String datePattern = "Period\\{([0-9-]{10}),([0-9-]{10})}";
        Pattern dateR = Pattern.compile(datePattern);
        Matcher dateM = dateR.matcher(lines);
        if (dateM.find()) {
            start = LocalDate.parse(dateM.group(1));
            end = LocalDate.parse(dateM.group(2));
        }

        length = (int) DAYS.between(start, end) + 1;
        intervalSet = new NoBlankIntervalSet<>(new UniqueIntervalSet<>(new CommonIntervalSet<>(length)));
    }

    private static void display() {
        System.out.println("排班人员信息如下：（已编号）");
        System.out.println("编号\t姓名\t\t\t\t职务\t\t\t联系方式");

        for (int i = 0; i < employees.size(); i++) {
            System.out.println(i + "\t" + employees.get(i));
        }

        System.out.println("排班日期：" + start + " 至 " + end);
    }

    private static void manualSchedule() throws IntervalConflictException {
        System.out.print("请输入排班人员编号，排班起止时间：（例：1 2020-06-01 2020-06-07）");
        String[] str = new Scanner(System.in).nextLine().split(" ");
        int index = Integer.parseInt(str[0]);
        int startIndex = (int) DAYS.between(start, LocalDate.parse(str[1]));
        int endIndex = (int) DAYS.between(start, LocalDate.parse(str[2]));

        intervalSet.insert(new Period(startIndex, endIndex), employees.get(index));
    }

    private static void autoSchedule() throws IntervalConflictException {
        List<Period> blanks = intervalSet.getBlank();
        Set<Employee> labels = intervalSet.labels();

        for (Period blank : blanks) {
            for (Employee e : employees) {
                if (!labels.contains(e)) {
                    labels.add(e);
                    intervalSet.insert(blank, e);
                    break;
                }
            }
        }

        System.out.println("自动安排完成");
    }

    private static void view() {
        List<Period> blankList = intervalSet.getBlank();
        if (blankList.size() == 0) {
            System.out.println("已全部安排完成");
        }

        int blankSum = 0;

        System.out.print("待安排时间段：");
        for (Period blank : blankList) {
            System.out.print(indexToDate(blank.getStart()) + "~" + indexToDate(blank.getEnd()) + "\t");
            blankSum += blank.getEnd() - blank.getStart() + 1;
        }

        System.out.println("待安排时间段占比" + (double) blankSum / length);
    }

    private static void remove() {
        System.out.print("输入想移除排班人员的编号");
        int index = new Scanner(System.in).nextInt();

        intervalSet.remove(employees.get(index));
        employees.remove(index);

        System.out.print("已成功移除。请注意编号的变化，是否要重新查看编号（1/0）");
        if (new Scanner(System.in).nextInt() == 1) {
            display();
        }
    }

    private static void export() {
        String[] strings = intervalSet.toString().split("\n");

        if (strings[0].equals("There is still empty interval")) {
            System.out.println("排班表有空缺，不能输出");
            return;
        }

        StringBuilder stringBuilder = new StringBuilder("排班表如下\n");

        for (int i = 0; i < strings.length; i++) {
            stringBuilder.append(indexToDate(i)).append('\t').append(strings[i]).append('\n');
        }

        System.out.println(stringBuilder);
    }

    private static void check() throws Exception {
        String rosterPattern = "([A-Za-z0-9]+)\\{([0-9-]{10}),([0-9-]{10})(})";
        Pattern rosterR = Pattern.compile(rosterPattern);
        Matcher rosterM = rosterR.matcher(lines);

        //略过时间段
        rosterM.find();
        while (rosterM.find()) {
            int startIndex = (int) DAYS.between(start, LocalDate.parse(rosterM.group(2)));
            int endIndex = (int) DAYS.between(start, LocalDate.parse(rosterM.group(3)));
            String name = rosterM.group(1);
            Employee e = null;

            for (Employee employee : employees) {
                if (name.equals(employee.getName())) {
                    e = employee;
                }
            }

            intervalSet.insert(new Period(startIndex, endIndex), e);
        }

        List<Period> blankList = intervalSet.getBlank();
        if (blankList.size() == 0) {
            System.out.println("该文件所给排班表合法");
        } else {
            System.out.println("该文件所给排班表不合法");
        }
    }

    public static void main(String[] args) throws IOException, IntervalConflictException {
        System.out.println("—————————————————————欢迎使用DutyRoster排班系统—————————————————————");
        System.out.print("请输入配置文件名：");
        String filename = new Scanner(System.in).nextLine();

        initial(filename);
        display();

        System.out.println("*************************现在开始排班*******************************");
        System.out.println("共有7个功能：1 手动排班  2 自动排班  3 查看已排班情况  4 删除某位排班人员  5 输出排班表  6 退出  7 对给定排班文件进行检查");

        int mode;

        while (true) {
            System.out.print("请选择功能：（输入对应数字即可）");
            mode = new Scanner(System.in).nextInt();
            switch (mode) {
                case 1:
                    manualSchedule();
                    break;
                case 2:
                    autoSchedule();
                    break;
                case 3:
                    view();
                    break;
                case 4:
                    remove();
                    break;
                case 5:
                    export();
                    break;
                case 6:
                    System.out.println("已成功退出");
                    System.exit(0);
                case 7:
                    try {
                        check();
                    } catch (Exception e) {
                        System.out.println("该文件所给排班表不合法");
                    }
                    return;
            }
        }
    }

    private static LocalDate indexToDate(int index) {
        return start.plusDays(index);
    }
}
