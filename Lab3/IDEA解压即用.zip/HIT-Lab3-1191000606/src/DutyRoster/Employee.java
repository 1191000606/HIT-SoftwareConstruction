package DutyRoster;

//An immutable ADT represent employees.
public class Employee {
    private final String name;
    private final String rank;
    private final String phoneNumber;

    //AF: name,rank,phoneNumber represent all necessary information of employee.
    //RI: phoneNumber should consist of 11 number. All fields should not be null.
    //safe from exposure: All fields are private and final. No setter method provided.

    Employee(String name, String rank, String phoneNumber) {
        this.name = name;
        this.rank = rank;
        this.phoneNumber = phoneNumber;
        checkRep();
    }

    public String getName() {
        return name;
    }

    private void checkRep() {
        assert name != null;
        assert rank != null;
        assert phoneNumber != null;
    }

    @Override
    public int hashCode() {
        return name.hashCode() + rank.hashCode() + phoneNumber.hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }

        if (!(obj instanceof Employee)) {
            return false;
        }

        Employee e = (Employee) obj;

        return name.equals(e.name) && rank.equals(e.rank) && phoneNumber.equals(e.phoneNumber);
    }

    @Override
    public String toString() {
        return name + "\t\t" + rank + "\t\t" + phoneNumber;
    }
}
